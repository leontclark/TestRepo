package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class BeginPreScan extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String sandbox_id
	private Boolean auto_scan
	private String buildIdProperty
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new BeginPreScan()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		sandbox_id = inProps.sandbox_id
		auto_scan = false
		if (inProps.auto_scan && inProps.auto_scan.equalsIgnoreCase("true")) {
			auto_scan = true
		}
		buildIdProperty = inProps.buildIdProperty
		
		// Summarize parameters
		Logger.info "Calling BeginPreScan"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Begin the prescan
		XmlResult xmlResult = uploadApi.beginPreScan(appId, sandbox_id, auto_scan)
		setOutputProperty(xmlResult)
		if (buildIdProperty) {
			outProps.put( buildIdProperty, uploadApi.extractBuildIdFromBeginPreScanResults(xmlResult) )
		}
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   auto_scan=${auto_scan}"
		Logger.info "   buildIdProperty='${buildIdProperty}'"
		super.displayParameters();
	}
	
	
}
