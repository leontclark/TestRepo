package plugin

import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.ibm.issr.core.log.Logger;
import com.veracode.apiwrapper.wrappers.UploadAPIWrapper;

class GetAppList extends CoreVeraCodePlugin {
	// Arguments
	private boolean include_user_info
	
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GetAppList()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		include_user_info = false
		if (inProps.include_user_info && inProps.include_user_info=="true") {
			include_user_info = true
		}
		
		// Summarize parameters
		Logger.info "Calling GetAppList"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		XmlResult xmlResult = uploadApi.getAppList( include_user_info )
		
		// TODO - this is TEMPORARY CODE
//		String app_id = uploadApi.getAppId("LTC Test")
//		Logger.info("App_id for 'LTC Test' is ${app_id}")
		
		Logger.info("XML Result is " + xmlResult.xmlContentsAsString )

		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   include_user_info='${include_user_info}'"
		super.displayParameters();
	}
	
	


}
