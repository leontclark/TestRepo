package plugin

import java.text.SimpleDateFormat

import veracode.VeracodeResultsApi
import veracode.VeracodeUploadApi
import veracode.XmlResult

import com.ibm.issr.core.log.Logger
import com.veracode.apiwrapper.wrappers.*

class UploadFileAndScan extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String filename
	private String sandbox_id
	private String save_as
	private String modules
	private Integer timeout_for_preScan
	private Integer timeout_for_scan
	private Boolean scan_all_top_level_modules
	private String start_new_build
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new UploadFileAndScan()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		filename = inProps.filename
		sandbox_id = inProps.sandbox_id
		save_as = inProps.save_as
		modules = inProps.modules
		start_new_build = inProps.start_new_build
		scan_all_top_level_modules = false
		if (inProps.scan_all_top_level_modules && inProps.scan_all_top_level_modules.equalsIgnoreCase("true")) {
			scan_all_top_level_modules = true
		}
		timeout_for_preScan = 20
		if (inProps.timeout_for_preScan) {
			timeout_for_preScan = inProps.timeout_for_preScan.toInteger()
		}
		timeout_for_scan = 120
		if (inProps.timeout_for_scan) {
			timeout_for_scan = inProps.timeout_for_scan.toInteger()
		}


		// Summarize parameters
		Logger.info "Calling UploadFile"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Optionally start a new Veracode build
		if (start_new_build.toBoolean()) {
			String version = (new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")).format(new Date())
			uploadApi.createBuild(appId, version)
		}

		// Upload the file
		XmlResult xmlResult = uploadApi.uploadFile(appId, filename, sandbox_id, save_as)
		Logger.info "Uploading the file returned: " + xmlResult.xmlContentsAsString
		
		// Begin pre-scan
		xmlResult = uploadApi.beginPreScan(appId, sandbox_id, false)
		Logger.info "Begin PreScan returned: " + xmlResult.xmlContentsAsString
		// get the build_id
		String build_id = uploadApi.extractBuildIdFromBeginPreScanResults(xmlResult)
		
		// Wait for result or timeout
		Logger.info "Waiting for completion of preScan"
		// set retry interval for 15 seconds
		def interval = 15L * 1000L
		def currentTime = System.currentTimeMillis()
		def timeout = currentTime + (timeout_for_preScan * 60L * 1000L)
		while (true) {
			def results = uploadApi.isPreScanComplete(appId, build_id, sandbox_id)
			if (results.isComplete) {
				break
			}
			if (System.currentTimeMillis() > timeout) {
				exitWithErrorMessage("The PreScan timeout out ($timeout_for_preScan minutes) before completing")
			}
			Thread.sleep(interval)
		}
		Logger.info "preScan is complete"
		
		// make sure that the preScan was successful
		xmlResult = uploadApi.getPreScanResults(appId, build_id, sandbox_id)
		Logger.info "preScan returned: " + xmlResult.xmlContentsAsString
		
		// Start the scan
		xmlResult = uploadApi.beginScan(appId, modules, scan_all_top_level_modules, sandbox_id )
		Logger.info "Begin PreScan returned: " + xmlResult.xmlContentsAsString
		build_id = xmlResult.xmlDom.@build_id.toString()
		
		VeracodeResultsApi resultsApi = new VeracodeResultsApi(new ResultsAPIWrapper(), username, password, proxyHost, proxyPort )

		// Wait for result or timeout
		Logger.info "Waiting for completion of Scan"
		// set retry interval for 30 seconds
		interval = 30L * 1000L
		currentTime = System.currentTimeMillis()
		timeout = currentTime + (timeout_for_scan * 60L * 1000L)
		while (true) {
			def results = resultsApi.isScanComplete(build_id)
			if (results.isComplete) {
				break
			}
			if (System.currentTimeMillis() > timeout) {
				exitWithErrorMessage("The Scan timeout out ($timeout_for_scan minutes) before completing")
			}
			Thread.sleep(interval)
		}
		Logger.info "scan is complete"

		
		// Get the scan results (as xml)
		xmlResult = resultsApi.getScanResults(build_id)
		Logger.info "scan returned: " + xmlResult.xmlContentsAsString
		
		// set the output results
		setOutputProperty(xmlResult)
		
		// Was the scan a success
		def result = resultsApi.didTheScanPass(build_id)
		if (! result.passed) {
			throw new Exception( "The scan did not pass" )
		}
		
		
	}

	@Override
	protected void displayParameters() {
		Logger.info "   filename='${filename}'"
		Logger.info "   save_as='${save_as}'"
		Logger.info "   appName='${appName}'"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   modules='${modules}'"
		Logger.info "   scan_all_top_level_modules=${scan_all_top_level_modules}"
		Logger.info "   timeout_for_preScan='${timeout_for_preScan}'"
		Logger.info "   timeout_for_scan='${timeout_for_scan}'"
		Logger.info "   start_new_build='${start_new_build}'"
		super.displayParameters();
	}
	
	
}
