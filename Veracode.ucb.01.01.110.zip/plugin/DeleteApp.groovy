package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class DeleteApp extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String description
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new DeleteApp()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		
		// Summarize parameters
		Logger.info "Calling DeleteApp"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Delete the application
		XmlResult xmlResult = uploadApi.deleteApp(appId)
		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		super.displayParameters();
	}
	
	
}
