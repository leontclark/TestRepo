package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class IsPreScanComplete extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String build_id
	private String sandbox_id
	private String completeProperty
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new IsPreScanComplete()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		build_id = inProps.build_id
		sandbox_id = inProps.sandbox_id
		completeProperty = inProps.completeProperty
		
		// Summarize parameters
		Logger.info "Calling BeginPreScan"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Begin the prescan
		def result = uploadApi.isPreScanComplete(appId, build_id, sandbox_id)
		setOutputProperty(result.xmlResult)
		if (completeProperty) {
			if (result.isComplete) {
				outProps.put(completeProperty, "true")
			} else {
				outProps.put(completeProperty, "false")
			}
		}
		
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   build_id='${build_id}'"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   completeProperty='${completeProperty}'"
		super.displayParameters();
	}
	
	
}
