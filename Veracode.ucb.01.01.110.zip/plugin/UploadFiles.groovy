package plugin

import java.text.SimpleDateFormat

import veracode.VeracodeUploadApi
import veracode.XmlResult

import com.ibm.issr.core.log.Logger
import com.veracode.apiwrapper.wrappers.*

class UploadFiles extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String baseDir
	private String includes
	private String excludes
	private String sandbox_id
	private String start_new_build
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new UploadFiles()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		baseDir = inProps.baseDir
		includes = inProps.includes
		excludes = inProps.excludes
		sandbox_id = inProps.sandbox_id
		start_new_build = inProps.start_new_build
		
		// Summarize parameters
		Logger.info "Calling UploadFiles"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) { 	
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Optionally start a new Veracode build
		if (start_new_build.toBoolean()) {
			String version = (new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")).format(new Date())
			uploadApi.createBuild(appId, version)
		}
		
		// Upload the file
		XmlResult xmlResult = uploadApi.uploadFiles( appId, baseDir, includes, excludes, sandbox_id )
		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   baseDir='${baseDir}'"
		Logger.info "   includes='${includes}'"
		Logger.info "   excludes='${excludes}'"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   start_new_build='${start_new_build}'"
		super.displayParameters();
	}
}
