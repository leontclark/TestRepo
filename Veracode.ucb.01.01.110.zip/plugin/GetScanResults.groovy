package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeResultsApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class GetScanResults extends CoreVeraCodePlugin {
	// Arguments
	private String build_id
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GetScanResults()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		build_id = inProps.build_id
		
		// Summarize parameters
		Logger.info "Calling GetScanResults"
		displayParameters()
		
		VeracodeResultsApi resultsApi = new VeracodeResultsApi(new ResultsAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// execute
		XmlResult xmlResult = resultsApi.getScanResults(build_id)
		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   build_id='${build_id}'"
		super.displayParameters();
	}
	
	
}
