package com.ibm.issr.rest

import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpGet

import com.ibm.issr.core.log.Logger;

/**
 * This is an abstraction of a REST GET call to be used in conjunction with the RestClient class.
 * @author ltclark
 *
 */
class RestGet extends RestOperation {
	private HttpGet method;
	
	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 */
	public RestGet( RestClient restClient ) {
		super( restClient );
		method = new HttpGet();
	}
	
	/**
	 * Perform the GET call!!
	 * @return Returns the response
	 */
	public RestResponse get() {
		// Build the full url
		method.setURI( new URI(this.fullUrl) );
		Logger.debug("RestGet.get('${this.fullUrl}')")
		response = restClient.client.execute(method)
		return new RestResponse( this, response )
	}
}
