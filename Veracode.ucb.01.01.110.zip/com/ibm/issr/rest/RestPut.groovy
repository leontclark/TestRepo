package com.ibm.issr.rest

import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpPut
import org.apache.http.entity.StringEntity

/**
 * This is an abstraction of a REST PUT call to be used in conjunction with the RestClient class.
 * @author ltclark
 *
 */
class RestPut extends RestOperation {
	private HttpPut method;
	private String cachedPayload="";		// cache payload for debugging purposes
	
	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 */
	public RestPut( RestClient restClient ) {
		super( restClient );
		method = new HttpPut();
	}
	
	/**
	 * Sets the body/contents/payload of the PUT call to a string value.
	 * @param payload
	 * @return Return 'this'.
	 */
	public RestPut setPayload( String payload ) {
		if (payload) {
			method.setEntity(new StringEntity(payload));
			cachedPayload = payload
		}
		return this;
	}
	
	/**
	 * Perform the PUT call!!
	 * @return Returns the response
	 */
	public RestResponse put() {
		// Build the full url
		method.setURI( new URI(this.fullUrl) );
		response = restClient.client.execute(method)
		return new RestResponse( this, response )
	}
}
