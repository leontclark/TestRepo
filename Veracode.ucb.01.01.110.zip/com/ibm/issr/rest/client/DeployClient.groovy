package com.ibm.issr.rest.client

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.plugin.PluginHelper
import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.entity.UCDApplication
import com.ibm.issr.ucd.entity.UCDTeam;

/**
 * This class contains various standard REST call wrappers for working with UrbanCode
 * Deploy clients and servers.  This is actually a lightweight class.  In fact, this
 * could have been implemented as a bunch of static methods.
 * 
 * @author ltclark
 *
 */
class DeployClient extends LogTracingClass {
	private RestClient restClient;

	/**
	 * Constructor
	 * @param restClient The {@link RestClient} connection handle for the appropriate UrbanCode Deploy
	 * server. 
	 */
	public DeployClient( RestClient restClient ) {
		this.restClient = restClient
	}
	
	/**
	 * Returns the rest client.
	 */
	public RestClient getRestClient() {
		return restClient;
	}
	
	/**
	 * Calls and return the UCD System Configuration which is a map of the system values.
	 * For example, use this to retrieve the SMTP email system settings.
	 */
	def getSystemConfiguration() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/system/configuration")
				.get()
			response.throwExceptionOnBadResponse()
			return response.responseAsObject
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
			
	}

	/**
	 * <p>Sets a Process Request property, which is a property associated with a specific runtime
	 * instance of a Process.</p>
	 * <p>Note that their are three types of processes - application processes, component processes,
	 * and generic processes.  Each type of process has its own api for setting Process Request properties.
	 * This function simply tries each type until one works or they all fail.</p>
	 * @param processRequestId The ID of the Process Request.  Note that some common ways to get to the 
	 * process request is the property request.id, which is the ID of the current process and parentResource.id which
	 * is the id of the parent process (if the process is nested, such as an App process that called a Component
	 * process).
	 * @param propertyName The name of the property to set.
	 * @param propertyValue The value of the property.
	 * @param secure Is this a secure property?  Defaults to false.
	 * @return
	 */
	public DeployClient setProcessRequestProperty( String processRequestId, String propertyName, String propertyValue, boolean secure=false) {
		def payload = [[
				name: propertyName,
				value: propertyValue,
				secure: "${secure}"			// Note that this has to be a string and not a boolean value (learned by trial and error)
			]]
		def jsonBuilder = new groovy.json.JsonBuilder()
		jsonBuilder payload
		String payloadString = jsonBuilder.toString()

		// Try the application process first
		RestPut applicationRequestPut = new RestPut( restClient )
		RestResponse applicationRequestResponse = applicationRequestPut.setPath("/rest/deploy/applicationProcessRequest/${processRequestId}/saveProperties")
				.setPayload(payloadString)
				.put()

		if (! applicationRequestResponse.ok) {
			// the application process failed, so try the component process
			RestPut componentRequestPut = new RestPut( restClient )
			RestResponse componentRequestResponse = componentRequestPut.setPath("/rest/deploy/componentProcessRequest/${processRequestId}/saveProperties")
					.setPayload(payloadString)
					.put()

			if (! componentRequestResponse.ok) {
				// Both the Application and Component Process Requests failed, try a generic Process Request
				RestPut genericRequestPut = new RestPut( restClient )
				RestResponse genericRequestResponse = genericRequestPut.setPath("/rest/process/request/${processRequestId}/saveProperties")
						.setPayload(payloadString)
						.put()

				genericRequestResponse.throwExceptionOnBadResponse()
			}
		}
		return this
	}

	/**
	 * Given a Component Name, this returns the corresponding Component ID.  Throws
	 * exception if not found.
	 * @param componentName The name of the component.
	 * @return Returns the Component ID String
	 */
	String getComponentIdForName( String componentName ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/cli/component/info")
				.addParameter("component", componentName)
				.get()
			response.throwExceptionOnBadResponse()
	
			return response.responseAsObject.id
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}

	/**
	 * Does the named Component Version exist?
	 * @param componentId The UCD ID of the component.
	 * @param versionName The Name of the desired component Version.
	 */
	boolean doesNamedComponentVersionExist( String componentId, String versionName ) {
		RestGet restGet = new RestGet(restClient)

		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/component/${componentId}/versions/false")
				.addParameter("name", versionName)
				.get()

			response.throwExceptionOnBadResponse()
	
			return (response.responseAsObject.size() > 0)
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}

	/**
	 * Returns the component version ID of the given component version.  Throws exception if
	 * not found.
	 * @param componentId The UCD ID of the component.
	 * @param versionName The Name of the desired component Version.
	 * @return The ID of the component version.
	 */
	String getComponentVersionIdForName( String componentId, String versionName ) {
		RestGet restGet = new RestGet(restClient)

		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/component/${componentId}/versions/false")
				.addParameter("name", versionName)
				.get()

			response.throwExceptionOnBadResponse()
	
			def componentVersionEntityList = response.responseAsObject;
			if (componentVersionEntityList.size() == 0) {
				PluginHelper.abortPlugin( "No version named ${versionName} was found" )
			}
	
			return componentVersionEntityList[0].id
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}


	/**
	 * Does the given named Component Version Property exist?  Note that this checks the "Version Property Definitions" for the
	 * component and NOT to see if a specific Component Version has a defined value.
	 * @param componentId The ID of the Component.
	 * @param propertyName The name of the Component Version property.
	 * @return True if the property exists, false if not.
	 */
	boolean doesComponentVersionPropertyExist( String componentId, String propertyName ) {
		def propertySheetPath = getPropertySheetDefForComponentVersion(componentId);

		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath(propertySheetPath)
				.get()
			response.throwExceptionOnBadResponse()
	
			// See if the named property is in the property sheet
			def propertySheet = response.responseAsObject
			def propertyExists = false
			propertySheet.each() { propertySheetEntry ->
				if (propertySheetEntry.name.equals(propertyName)) {
					propertyExists = true;
				}
			}
			return propertyExists;
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}


	/**
	 * Gets the value for a Component Version Property.
	 * @param componentId The ID of the Component.
	 * @param versionId The ID of the Component Version.
	 * @param propertyName The name of the property.
	 * @return Returns the value of the property or an empty string if not found.
	 */
	String getComponentVersionProperty( String componentId, String versionId, String propertyName ) {

		RestGet restGet = new RestGet(restClient)
		RestResponse response = restGet.setPath("/cli/version/versionProperties")
				.addParameter("component", componentId)
				.addParameter("version", versionId)
				.get()
		response.throwExceptionOnBadResponse()
		def propertyValues = response.responseAsObject

		// search for a name value pair in the 'propertyValues'
		boolean propertyFound = false;
		String propertyValue = "";
		propertyValues.each() { propertyValueEntry ->
			if (propertyValueEntry.name.equals(propertyName)) {
				propertyFound = true;
				propertyValue = propertyValueEntry.value;
			}
		}

		if (! propertyFound) {
			// The property was NOT found for the Component Version.  Check to see if a default value is defined by the Component's Version Property definitions
			RestGet restGetPropDefs = new RestGet(restClient)
			RestResponse responsePropDefs = restGetPropDefs.setPath("/cli/version/versionPropDefs")
					.addParameter("component", componentId)
					.get()
			responsePropDefs.throwExceptionOnBadResponse()
			def propertyDefinitions = responsePropDefs.responseAsObject
			propertyDefinitions.each() { propertyDefinition ->
				if (propertyDefinition.name.equals(propertyName)) {
					propertyValue = propertyDefinition.value;
				}
			}
		}
		return propertyValue;
	}


	/**
	 * Sets the value for a Component Version Property.
	 * @param componentId The ID of the Component.
	 * @param versionId The ID of the Component Version.
	 * @param propertyName The name of the property.
	 * @param propertyValue The value to set the property to.
	 * @param createIfMissing IF there is no such Component Version Property, then it is create if (and only if) 'createIfMissing' is true.  Otherwise,
	 * the property is simply not set.
	 * @param propertyType If the property is created (see createIfMissing parameter), this is the UrbanCode Deploy property data type, such as TEXT or TEXTAREA
	 * @return True if the property is defined, or false if it isn't.  Throws an exception if anything fails.
	 */
	boolean setComponentVersionProperty( String componentId, String versionId, String propertyName, String propertyValue, boolean createIfMissing=true, String propertyType="TEXT" ) {
		boolean doesPropertyExist = doesComponentVersionPropertyExist(componentId, propertyName);
		if (! doesPropertyExist) {
			if (createIfMissing) {
				createComponentVersionProperty( componentId, propertyName, propertyType );
				doesPropertyExist = true;
			}
		}
		if (doesPropertyExist) {
			// set the property
			RestPut restPut = new RestPut(restClient)
			RestResponse response = restPut.setPath("/cli/version/versionProperties")
					.addParameter("component", componentId)
					.addParameter("version", versionId)
					.addParameter("name", propertyName)
					.addParameter("value",propertyValue)
					.addParameter("isSecure", "false")
					.put()
			response.throwExceptionOnBadResponse()
		}
		return doesPropertyExist;
	}


	/**
	 * Create the given named Component Version Property exist?  Note that this does NOT define value.  This should only be called if
	 * the property doesn't exist.  Throws exception if there is a problem.
	 * @param componentId The ID of the Component.
	 * @param propertyName The name of the Component Version property.
	 * @param propertyType The UCD property type to use in creating it, such as "TEXT" or "TEXTAREA".
	 */
	void createComponentVersionProperty( String componentId, String propertyName, String propertyType="TEXT" ) {
		def newPropertyDef = [name:propertyName,label:"",type:propertyType,value:"",required:"false",description:"",inherited:false];
		def jsonBuilder = new groovy.json.JsonBuilder();
		jsonBuilder newPropertyDef
		// use latest propertySheet URL (the url changes)
		RestPut restPut = new RestPut(restClient)
		RestResponse response = restPut.setPath( getPropertySheetDefForComponentVersion(componentId))
				.setPayload(jsonBuilder.toString())
				.put()
		response.throwExceptionOnBadResponse()
	}


	/**
	 * Private function that returns the current Property Sheet URL for the given ComponentID.  Note
	 * that the property sheet URL is version dependent (it changes each time any property definition is changed).
	 */
	private String getPropertySheetDefForComponentVersion( String componentId )
	{
		RestGet restGet = new RestGet(restClient)
		RestResponse response = restGet.setPath("/cli/component/info")
				.addParameter("component", componentId)
				.get()
		response.throwExceptionOnBadResponse()

		def component = response.responseAsObject
		// the url is component.versionPropSheetDef.path + component.versionPropSheetDef.version + "/propDefs"
		// -and- the '/'s in the component.versionPropSheetDef.path MUST be changed to '%26' (or it doesn't work)
		return "/property/propSheetDef/" + component.versionPropSheetDef.path.replaceAll('/','%26') + "." + component.versionPropSheetDef.version + "/propDefs"
	}
	
	/**
	 * Looks up the given Role name and returns the corresponding internal ID for the role.  Throws an exception if not found.
	 */
	String translateRolenameToId( String rolename )
	{
		RestGet restGet = new RestGet(restClient)
		def roles = null
		RestResponse response = null
		try {
			response = restGet.setPath("/security/role")
					.get()
			response.throwExceptionOnBadResponse()
			
			roles = response.responseAsObject
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
		def found = false
		def retval = ""
		// Iterate roles looking for match
		roles.each { roleEntry ->
			if (roleEntry.name.equalsIgnoreCase(rolename)) {
				found = true
				retval = roleEntry.id
			}
		}
		if (found) {
			return retval
		} else {
			throw new RuntimeException( "Unable to find a security role named '${rolename}'" )
		}
	}

	/**
	 * Returns The list of permissions (as a JSON to Object translation) of the given role id.
	 * @param roleId The role id.
	 * @return The list of permissions.
	 * This is an array.  The structure of the array is ...<pre>
	 * 		action - Represents the action with a nested structure
	 * 			id - The ID of the action
	 * 			name - The name of the action
	 * 			description - The description of the action
	 * 		resourceRole - IF (and ONLY if) this is an action against a role specific type, this is another element defining the branch.
	 * 			id - The ID of the resource type
	 * 			name - The name of the resource type
	 * 			description - The description of the resource type
	 * </pre>
	 */
	public getPermissionListForRoleId( String roleId ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/role/${roleId}/actionMappings")
					.get()
			response.throwExceptionOnBadResponse()
			
			return response.responseAsObject
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Sets a Role Permission
	 * @param roleId The ID of the role to set the permission for.
	 * @param actionId The ID of the permission.
	 * @param resourceRoleId This is optional and may be an empty string.  If it is not an empty string, then
	 * it is the 'resourceRole' id for resource role specific permissions.
	 */
	void setPermissionForRoleId( String roleId, String actionId, String resourceRoleId ) {
		def payload
		if (resourceRoleId) {
			payload = [ resourceRole:resourceRoleId, action:actionId ]
		} else {
			payload = [ action:actionId ]
		}
		def jsonBuilder = new groovy.json.JsonBuilder()
		jsonBuilder payload
		String payloadString = jsonBuilder.toString()
		
		RestPost restPost = new RestPost( restClient )
		RestResponse response = null
		try {
			response = restPost.setPath("/security/role/${roleId}/actionMappings")
				.setPayload( payloadString )
				.post()
			
			response.throwExceptionOnBadResponse()
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Returns the list of Roles/Role Configurations.
	 * @return The list as a Groovy object translated from JSON.  The result is a list of records with id, name, description and isDeletable.
	 */
	public getRoles() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/role")
					.get()
			response.throwExceptionOnBadResponse()
			
			return response.responseAsObject
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Returns a MAP of the types of resources in UCD.  Note that the underlying REST call
	 * returns both Resource Types AND special categories for the 'Role Configurations' option in the Settings UI tab.
	 * However, there is no obvious clear way to distinguish between the two.  This function also returns both, but
	 * with the 'isResourceType' flag to differentiate real types from the security groups (such as 'Web UI'). 
	 * @return Returns a list of the resource types.  Each entry has the following fields:<pre>
	 * 		id - The id of the type.
	 * 		name - The name of the type
	 * 		isResourceType - boolean.  Set to true if this really is a Resource Type and not just a security category (such as "Web UI").
	 * </pre>
	 */
	public getResourceTypes() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/resourceType")
					.get()
			response.throwExceptionOnBadResponse()
			
			def typeList = response.responseAsObject
			def returnList = []
			typeList.each { typeListEntry ->
				def newEntry = [:]
				newEntry.name = typeListEntry.name
				newEntry.id = typeListEntry.id
				if (newEntry.name.equalsIgnoreCase("Server Configuration") || newEntry.name.equalsIgnoreCase("WEB UI")) {
					newEntry.isResourceType = false
				} else {
					newEntry.isResourceType = true
				}
				returnList.add(newEntry)
			}
			return returnList
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}

	}
	
	
	/**
	 * Returns the application object for the named application.  This returns the structure returned by the /cli/application/info rest call.
	 */
	public getApplicationObjectByName( String applicationName ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/cli/application/info")
					.addParameter("application", applicationName)
					.get()
			response.throwExceptionOnBadResponse()
			
			return response.getResponseAsObject()
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	
	/**
	 * Returns the team object for the named team.  This returns the structure returned by the /security/team/{name} rest call.
	 */
	public getTeamObjectByName( String teamName ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/team/${teamName}")
					.get()
			response.throwExceptionOnBadResponse()
			
			return response.getResponseAsObject()
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	
	/**
	 * Given the name of a team, return its ID.  Throws exception on failure.
	 */
	public UCDTeam getTeamHandleByName( String teamName ) {
		def team = getTeamObjectByName( teamName )
		return new UCDTeam( restClient, teamName, team.id )
	}

}
