package com.ibm.issr.ucd.relationship

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.rest.RestClient
import com.ibm.issr.ucd.entity.UCDArtifact
import com.ibm.issr.ucd.entity.UCDResourceRole;
import com.ibm.issr.ucd.entity.UCDTeam;

/**
 * Represents one ResourceRole connection between an Artifact and a Team and a ResourceRole.
 * Note that the ResourceRole is optional.  If null, then it is the Standard resource role.
 * @author ltclark
 *
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=false)
@groovy.transform.EqualsAndHashCode
class UCDArtifactTeamAssociation extends LogTracingClass {
	// The artifact (application, environment, component, etc) - required
	UCDArtifact	artifact
	// The team - required
	UCDTeam team
	/**
	 * The ResourceRole, such as 'DEV' or 'PROD'.  This is null for standard.
	 */
	UCDResourceRole resourceRole
	
	String name;		// name of the artifact
	String id;			// artifact's internal id
	protected RestClient restClient;
	
	// make name and id read only
	protected void setName(String value) { this.name = value }
	protected void setId(String value) { this.id = value }

	/**
	 * Constructor
	 * @param artifact The artifact, which is required.
	 * @param team The team, which is required.
	 * @param resourceRole The Resource Role, which is optional.  It should actually be null if it is
	 * the 'Standard' resource role.
	 */
	public UCDArtifactTeamAssociation( UCDArtifact artifact, UCDTeam team, UCDResourceRole resourceRole ) {
		assert artifact
		assert team
		// resourceRole may be null
		this.artifact = artifact
		this.team = team
		this.resourceRole = resourceRole
	}
}
