
package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient;

/**
 * A Resource Role is a type of Artifact, such as a "DEV" Environment.
 * This is ONLY used for custom Resource Roles.  For standard roles, simply use a null
 * value for the UCDResourceRole instead.
 * @author ltclark
 *
 */
@groovy.transform.EqualsAndHashCode(callSuper=true)
class UCDResourceRole extends UCDElementWithNameAndId {

	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param resourceRoleName The name of the resourceRole
	 * @param resourceRoleId The id of the resourceRole
	 */
	public UCDResourceRole( RestClient restClient, String resourceRoleName, String resourceRoleId ) {
		super( restClient, resourceRoleName, resourceRoleId )
	}

}
