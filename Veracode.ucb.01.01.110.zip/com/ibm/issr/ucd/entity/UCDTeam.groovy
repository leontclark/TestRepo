package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient;

/**
 * Handle to one UCD Security Team
 * @author ltclark
 *
 */
class UCDTeam extends UCDElementWithNameAndId {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param teamName The name of the team
	 * @param teamId The id of the team
	 */
	public UCDTeam( RestClient restClient, String teamName, String teamId ) {
		super( restClient, teamName, teamId )
	}

}
