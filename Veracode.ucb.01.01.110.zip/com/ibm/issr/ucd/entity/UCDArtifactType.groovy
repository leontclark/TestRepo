
package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse

/**
 * This class uniquely identifies the different types of UCD Artifacts, such as Components,
 * Applications, Component Templates and so on.  The names and ids are provided by the 
 * '/security/resourceType' API call.  The list of types is assumed to be constant.
 * Note - use the UCDArtifactTypeMgr class to access and manage the list of these types.
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=true)
class UCDArtifactType extends UCDElementWithNameAndId {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param artifactTypeName The name of the artifact type
	 * @param artifactTypeId The id of the artifact type
	 */
	public UCDArtifactType( RestClient restClient, String artifactTypeName, String artifactTypeId ) {
		super( restClient, artifactTypeName, artifactTypeId )
	}

	/**
	 * Returns the list of custom resource roles for this Artifact Type.  Note that the elements
	 * of the set are of type UCDResourceRole.  This does NOT return the 'Standard' resource role.
	 */
	public Set getCustomResourceRoles() {
		Set resourceRoles = new HashSet()
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/resourceType/${this.name}/resourceRoles")
					.get()
			response.throwExceptionOnBadResponse()
			
			def returnedData = response.getResponseAsObject()
			returnedData.each { returnedResourceRole ->
				resourceRoles.add(new UCDResourceRole(restClient, returnedResourceRole.name, returnedResourceRole.id))
			}
	
			return resourceRoles
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
}
