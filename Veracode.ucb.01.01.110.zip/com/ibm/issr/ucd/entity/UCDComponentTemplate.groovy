package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.manage.UCDArtifactTypeMgr;

/**
 * Handle to a UCD ComponentTemplate
 * 
 * @author ltclark
 *
 */
class UCDComponentTemplate extends UCDArtifact {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param componentTemplateName The name of the componentTemplate
	 * @param componentTemplateId The id of the componentTemplate
	 */
	public UCDComponentTemplate( RestClient restClient, String componentTemplateName, String componentTemplateId ) {
		super( restClient, componentTemplateName, componentTemplateId, UCDArtifactTypeMgr.getInstance(restClient).getArtifactType("Component Template") )
	}
	
	/**
	 * Returns a List of the Team Associations (UCDArtifactTeamAssociation).  Each UCDArtifact class must implement
	 * its own (unique) version of this function.
	 */
	public Set getTeamAssociations() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/componentTemplate/${this.id}")
				.get()
			response.throwExceptionOnBadResponse()
			
			return super.convertExtendedSecurityToTeamAssociations(response.getResponseAsObject())
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}

}
