package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.manage.UCDArtifactTypeMgr;

/**
 * Handle to a UCD Component
 * 
 * @author ltclark
 *
 */
class UCDComponent extends UCDArtifact {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param componentName The name of the component
	 * @param componentId The id of the component
	 */
	public UCDComponent( RestClient restClient, String componentName, String componentId ) {
		super( restClient, componentName, componentId, UCDArtifactTypeMgr.getInstance(restClient).getArtifactType("Component") )
	}
	
	/**
	 * Returns a List of the Team Associations (UCDArtifactTeamAssociation).  Each UCDArtifact class must implement
	 * its own (unique) version of this function.
	 */
	public Set getTeamAssociations() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/component/${this.id}")
				.get()
			response.throwExceptionOnBadResponse()
			
			return super.convertExtendedSecurityToTeamAssociations(response.getResponseAsObject())
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}

	/**
	 * Returns the Component Template for this component or null if there is no component template.
	 */
	public UCDComponentTemplate getComponentTemplate() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/component/${this.id}")
				.get()
			response.throwExceptionOnBadResponse()
			
			def componentObject = response.getResponseAsObject()
			
			if (componentObject.template) {
				return new UCDComponentTemplate(restClient, componentObject.template.name, componentObject.template.id)
			} else {
				return null
			}
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
}
