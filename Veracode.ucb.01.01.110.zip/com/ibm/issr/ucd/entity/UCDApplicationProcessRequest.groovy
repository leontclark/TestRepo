package com.ibm.issr.ucd.entity

import com.ibm.issr.core.log.Logger;
import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse

/**
 * An ApplicationProcessRequest is a previous application process execution and its results.
 * @author ltclark
 *
 */
class UCDApplicationProcessRequest extends UCDElementWithId
{
	/**
	 * Implementation notes
	 *  - It takes two REST calls to retrieve all of the data about the execution
	 *  	/rest/deploy/applicationProcessRequest/[id]
	 *  		contains summary information
	 *  	/rest/workflow/applicationProcessRequest/[id]
	 *  		contains the detailed process call tree OR an error message, such as 'error=Error starting workflow: The process could not start: The following agents are offline: agent1'
	 */
	
	// This is the object returned by /rest/deploy/applicationProcessRequest/[id]
	private def deployData = null
	
	// This is the data returned by /rest/workflow/applicationProcessRequest/[id]
	private def workflowData = null
	
	// The properties of the request.  This is loaded on demand by the internal 'accessProperties' command
	// This is the raw object model returned by /rest/deploy/applicationProcessRequest/[id]/properties 
	private def _requestProperties = null
	
	
	/**
	 * Constructor - ALL of the fields are required.  Note that this constructor
	 * actually loads the data from UCD.
	 * @param restClient The handle to the REST API client.
	 * @param elementId The id of the element
	 */
	private UCDApplicationProcessRequest( RestClient restClient, String elementId ) {
		super( restClient, elementId )
		
		// Get the 'deploy data'
		RestGet restGet = new RestGet(restClient)
		RestResponse response = restGet.setPath("/rest/deploy/applicationProcessRequest/${elementId}")
					.get()
		response.throwExceptionOnBadResponse()
		deployData = response.getResponseAsObject()
		
		// get the 'workflow data'
		RestGet restWorkflowGet = new RestGet(restClient)
		RestResponse workflowResponse = restGet.setPath("/rest/workflow/applicationProcessRequest/${elementId}")
					.get()
		workflowResponse.throwExceptionOnBadResponse()
		workflowData = workflowResponse.getResponseAsObject()
	}
	
	/**
	 * Returns the properties (_requestProperties) loading them first if needed.
	 * @return The JSON based object model
	 */
	private accessProperties() {
		if (! _requestProperties) {
			Logger.trace("Loading properties for request id ${super.id}" )
			
			RestGet restGet = new RestGet(restClient)
			RestResponse response = restGet.setPath("/rest/deploy/applicationProcessRequest/${super.id}/properties ")
				.get()
			response.throwExceptionOnBadResponse()
			_requestProperties = response.getResponseAsObject()
		}
	}
	
	/**
	 * Loads the designated Application Process Request
	 * @param restClient The handle to the REST API client.
	 * @param elementId The id of the element
	 * @return Returns the newly loaded element.
	 */
	public static UCDApplicationProcessRequest load( RestClient restClient, String elementId ) {
		return new UCDApplicationProcessRequest(restClient, elementId)
	}
	
	/**
	 * Returns the name of the application that the process is part of.
	 */
	public String getApplicationName() {
		return deployData.application.name;
	}
	
	/**
	 * Returns the name of the environment for the process that ran.
	 * @return
	 */
	public String getEnvironmentName() {
		return deployData.environment.name
	}
	
	/**
	 * Returns the name of the user that ran the process.
	 * @return
	 */
	public String getUserName() {
		return deployData.userName
	}
	
	/**
	 * Returns the string result as "SUCCESS" or "FAILURE"
	 */
	public String getResult() {
		if (deployData.containsKey("result") && deployData.result.equalsIgnoreCase("SUCCEEDED")) {
			return "SUCCESS"
		} else {
			return "FAILURE"
		}
	}
	
	/**
	 * Returns the duration in seconds.
	 */
	public Long getDuration() {
		if (workflowData.containsKey("duration")) {
			return new Long(workflowData.duration) / 1000L	
		} else {
			return 0
		}
	}
	
	/**
	 * Returns the duration as a time string, such as "0:00:00" or "4:10:20".
	 */
	public String getDurationAsTimeString() {
		Long dur = getDuration()
		Long hours = dur / 3600
		dur = dur - hours* 3600
		Long minutes = dur / 60
		dur = dur - minutes * 60
		Long seconds = dur
		return sprintf( "%01d:%02d:%02d", hours, minutes, seconds )
	}
	
	/**
	 * Returns the start date of the request.  Note that if the start date is NOT available because it never
	 * started, then this returns the date that the deployment was requested.
	 */
	public Date getStartDate() {
		if (workflowData.containsKey("startDate")) {
			return new Date( new Long(workflowData.startDate) )
		} else {
			return new Date( new Long(deployData.submittedTime) )
		}
	}
	
	/**
	 * Does the request have a property with the matching name??
	 */
	public boolean hasRequestProperty( String propertyName ) {
		boolean retval = false
		def properties = accessProperties()
		properties.properties.each { def property ->
			if (property.name == propertyName) {
				retval = true
			}
		}
		return retval
	}
	
	/**
	 * Retrieves the value of the named property as a String.  Returns null if the property isn't found.
	 */
	public String getRequestProperty( String propertyName ) {
		String retval = null
		def properties = accessProperties()
		properties.properties.each { def property ->
			if (property.name == propertyName) {
				retval = property.value
			}
		}
		return retval
	}
}
