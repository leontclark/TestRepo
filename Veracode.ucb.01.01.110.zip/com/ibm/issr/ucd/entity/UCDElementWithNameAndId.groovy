package com.ibm.issr.ucd.entity

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.rest.RestClient;

/**
 * Numerous elements within UCD have names and id's, which include
 * artifacts (such as Applications, Components, etc), Teams and ResourceRoles. This
 * is a base class for ANY UCD Element which has a name and an ID.  Note that
 * instances of this type are uniquely identified by their 'id' field.  So,
 * if two different instances of this have the same id, but different names, they are
 * still considered to be equal (and have the same hashcode).
 * @author ltclark
 *
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=false, includes="name,id")
@groovy.transform.EqualsAndHashCode( includes="id", callSuper=false )
class UCDElementWithNameAndId extends UCDElementWithId {
	String name;		// name of the element
	String id;			// element's internal id
	protected RestClient restClient;
	
	// make name and id read only
	protected void setName(String value) { this.name = value }
	protected void setId(String value) { this.id = value }
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param elementName The name of the element
	 * @param elementId The id of the element
	 */
	public UCDElementWithNameAndId( RestClient restClient, String elementName, String elementId ) {
		assert restClient
		assert elementName
		assert elementId
		this.restClient = restClient
		this.name = elementName
		this.id = elementId
	}

}
