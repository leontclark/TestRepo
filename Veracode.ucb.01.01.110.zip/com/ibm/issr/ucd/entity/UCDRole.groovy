
package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient;
import com.ibm.issr.rest.RestGet;
import com.ibm.issr.rest.RestResponse;
import com.ibm.issr.ucd.relationship.UCDPermissionActionForResourceRole;

/**
 * Represents one security Role.
 * @author ltclark
 *
 */
class UCDRole extends UCDElementWithNameAndId {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param roleName The name of the role
	 * @param roleId The id of the role
	 */
	public UCDRole( RestClient restClient, String roleName, String roleId ) {
		super( restClient, roleName, roleId )
	}

	/**
	 * Returns the Set of permission actions.  More specifically, it returns the list
	 * of ResourceRole Permissions, such as 'View permission for Standard Environment' and
	 * 'View permission for DEV Environment' (but no entry for 'View Permission for PROD Environment').
	 * @return Returns a Set of type 'UCDPermissionActionForResourceRole'.
	 */
	public Set getPermissionActions() {
		Set permissions = new HashSet()
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/role/${this.id}/actionMappings")
				.get()
			response.throwExceptionOnBadResponse()
			def responseObject = response.responseAsObject
			
			responseObject.each() { responseElement ->
				UCDPermissionAction permissionAction = new UCDPermissionAction(restClient, responseElement.action.name, responseElement.action.id, responseElement.action.description)
				UCDResourceRole resourceRole = null
				if (responseElement.resourceRole) {
					resourceRole = new UCDResourceRole(restClient, responseElement.resourceRole.name, responseElement.resourceRole.id)
				}
				UCDPermissionActionForResourceRole permissionForResourceRole = new UCDPermissionActionForResourceRole(permissionAction, resourceRole)
				permissions.add(permissionForResourceRole)
			}
			
			return permissions
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
}
