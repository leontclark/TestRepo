package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.manage.UCDArtifactTypeMgr

/**
 * Handle to a UCD Environment
 */
class UCDEnvironment extends UCDArtifact {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param environmentName The name of the environment
	 * @param environmentId The id of the environment
	 */
	public UCDEnvironment( RestClient restClient, String environmentName, String environmentId ) {
		super( restClient, environmentName, environmentId, UCDArtifactTypeMgr.getInstance(restClient).getArtifactType("Environment") )
	}

	/**
	 * Returns a List of the Team Associations (UCDArtifactTeamAssociation).
	 */
	public Set getTeamAssociations() {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/environment/${this.id}")
				.get()
			response.throwExceptionOnBadResponse()
			
			return super.convertExtendedSecurityToTeamAssociations(response.getResponseAsObject())
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
}
