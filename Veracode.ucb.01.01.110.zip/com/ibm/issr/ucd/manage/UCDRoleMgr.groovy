package com.ibm.issr.ucd.manage

import com.ibm.issr.core.log.Logger;
import com.ibm.issr.rest.RestClient;
import com.ibm.issr.rest.RestGet;
import com.ibm.issr.rest.RestResponse;
import com.ibm.issr.ucd.entity.UCDRole;


/**
 * Interface to ALL of the defined security Roles (UCDRole).  Note that this is a singleton.
 * @author ltclark
 *
 */
class UCDRoleMgr {
	private RestClient restClient = null
	// The set of roles.  Entries are of type UCDRole
	private Set roles = new HashSet()
	private static UCDRoleMgr instance = null
	
	private UCDRoleMgr( RestClient restClient ) {
		this.restClient = restClient
		
		// Load the roles
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/role")
				.get()
			response.throwExceptionOnBadResponse()
			def responseObject = response.responseAsObject
			
			responseObject.each() { responseElement ->
				UCDRole role = new UCDRole(restClient, responseElement.name, responseElement.id)
				roles.add( role )
			}
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	static UCDRoleMgr getInstance( RestClient restClient ) {
		if (! this.instance) {
			this.instance = new UCDRoleMgr(restClient)
		}
		return this.instance
	}
	
	// Make set roles protected
	protected void setRoles( roles ) { this.roles = roles }

	/**
	 * Return the Set of roles.  The entries are of type UCDRole
	 */
	public Set getRoles() { return this.roles }
	
	/**
	 * Looks up and returns the named role or throws an exception.
	 * @param name Case sensitive name of the role.
	 */
	public UCDRole getRoleByName( String name ) {
		UCDRole retval = null
		roles.each() { UCDRole role ->
			if (role.name == name) {
				retval = role
			}
		}
		
		if (retval) {
			return retval
		} else {
			throw new RuntimeException( "Unable to find a security role named '${name}'" )
		}
	}
}
