package com.ibm.issr.ucd.manage

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.entity.UCDApplication

/**
 * Singleton class to manage UCDApplicatio'ns.
 * @author ltclark
 *
 */
class UCDApplicationMgr extends LogTracingClass {
	/**
	 * Private singleton instance
	 */
	private static UCDApplicationMgr instance = null
	
	/**
	 * The REST Client interface.
	 */
	private RestClient restClient = null
	
	
	/**
	 * Private constructor.
	 * @param restClient The rest client interface.
	 */
	private UCDApplicationMgr( RestClient restClient ) {
		assert restClient
		this.restClient = restClient
	}
	
	/**
	 * Returns the singleton instance.
	 */
	public static UCDApplicationMgr getInstance( RestClient restClient ) {
		if (! instance) {
			instance = new UCDApplicationMgr(restClient)
		}
		return instance
	}
	
	/**
	 * Returns a UCDApplication for the named application or throws exception if not found or error.
	 * @param applicationName The case sensitive name.
	 */
	public UCDApplication getApplicationByName( String applicationName ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/cli/application/info")
					.addParameter("application", applicationName)
					.get()
			response.throwExceptionOnBadResponse()
			
			def applicationObject = response.getResponseAsObject()
			
			return new UCDApplication(restClient, applicationObject.name, applicationObject.id)
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Returns the Set of all applications.  Data type of the set is UCDApplication.
	 * @return
	 */
	public Set getApplications() {
		
	}

}
