package com.ibm.issr.ucd.manage

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.entity.UCDTeam

/**
 * Singleton class to manage UCDTeam's
 * @author ltclark
 *
 */
class UCDTeamMgr {
	/**
	 * Private singleton instance
	 */
	private static UCDTeamMgr instance = null
	
	/**
	 * The REST Client interface.
	 */
	private RestClient restClient = null
	
	
	/**
	 * Private constructor.
	 * @param restClient The rest client interface.
	 */
	private UCDTeamMgr( RestClient restClient ) {
		assert restClient
		this.restClient = restClient
	}
	
	/**
	 * Returns the singleton instance.
	 */
	public static UCDTeamMgr getInstance( RestClient restClient ) {
		if (! instance) {
			instance = new UCDTeamMgr(restClient)
		}
		return instance
	}
	
	/**
	 * Returns a UCDTeam for the named team or throws exception if not found or error.
	 * @param teamName The case sensitive name.
	 */
	public UCDTeam getTeamByName( String teamName ) {
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/team/${teamName}")
					.get()
			response.throwExceptionOnBadResponse()
			
			def teamObject = response.getResponseAsObject()
			
			return new UCDTeam(restClient, teamObject.name, teamObject.id)
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Returns a Set of all of the teams.  The member data type of the Set is UCDTeam.
	 */
	public Set getTeams() {
		Set teams = new HashSet()
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/team")
					.get()
			response.throwExceptionOnBadResponse()
			
			def teamSetObject = response.getResponseAsObject()
	
			teamSetObject.each { teamObject ->
				teams.add(new UCDTeam(restClient, teamObject.name, teamObject.id))
			}
			
			return teams
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}


}
