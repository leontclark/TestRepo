package veracode

/**
 * Some of the veracode api calls involve long lag times.  For example, it can take
 * hours (or days) from when a scan is submitted until it is completed.  This is a helper
 * function for supporting 'dry runs'.  A dry run is when the Veracode wrapper functions are
 * called, but they return stubbed out data without actually calling the veracode api's.
 * This is intended to be used while developing and debugging this plugin and is not
 * intended for any actual production use.
 * 
 * This is a singleton class.
 * @author ltclark
 *
 */
class DryRunHelper {
	public static DryRunHelper instance = new DryRunHelper();
	
	/**
	 * This is a simulated XML return string (if not empty or null)
	 */
	public String dryRunXmlResults = ""
	
	private DryRunHelper() {
		
	}
	
	/**
	 * Resets the dry run information.
	 */
	public void reset() {
		dryRunXmlResults = ""
	}
}
