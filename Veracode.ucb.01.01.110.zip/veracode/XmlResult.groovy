package veracode

/**
 * It is handy for various XML calls to return both the raw XML String and the processed
 * XML DOM.  This simple class combines them.  Some of the API calls retrieve multiple
 * XML Results, so this is actually a list of results.  A number of the functions return
 * the net result of the list.  For example, isErrorResult() is true if any of the
 * listed results is an error.
 * @author ltclark
 *
 */
class XmlResult {
	public String xmlString
	public def xmlDom;
	public XmlResult nestedResult
	
	/**
	 * Constructor
	 * @param xmlString the string value of the xml result
	 * @param xmlDom the DOM value of the xml result
	 */
	public XmlResult( String xmlString, xmlDom ) {
		this.xmlString = xmlString
		this.xmlDom = xmlDom
		nestedResult = null
	}
	
	/**
	 * Constructor
	 * @param xmlString the string value of the xml result
	 * @param xmlDom the DOM value of the xml result
	 * @param nestedResult is a nested result(s)
	 */
	public XmlResult( String xmlString, xmlDom, XmlResult nestedResult ) {
		this.xmlString = xmlString
		this.xmlDom = xmlDom
		this.nestedResult = nestedResult
	}

	/**
	 * Is this XmlResult (or nested results) an 'Error' result?  It's an error result if the
	 * root elemement is of type 'error'
	 */
	public boolean isErrorResult() {
		if (xmlDom.name() == "error") {
			return true
		} else if (nestedResult) {
			return nestedResult.isErrorResult()
		} else {
			return false
		}
	}
	
	/**
	 * If (and only if) this result is an error result (where isErrorResult() is true),
	 * then this function returns the text of the error message.
	 */
	public String getErrorMsg() {
		if (xmlDom.name() == "error") {
			return xmlDom.text()
		} else if (nestedResult) {
			return nestedResult.getErrorMsg()
		} else {
			return ""
		}
	}
	
	/**
	 * Sets the nested result(s)
	 * @param nestedResult The nested result, which may be null.
	 * @return Returns 'this' as a convenience.
	 */
	public XmlResult setNestedResult( XmlResult nestedResult ) {
		this.nestedResult = nestedResult
		return this
	}
	
	/**
	 * Returns a string array where each member is one of the nested XML result strings.
	 */
	public String[] getXmlContents() {
		ArrayList results = []
		if (nestedResult) {
			results = nestedResult.getXmlContents()
		}
		results.add( xmlString )
		return results as String[]
	}
	
	/**
	 * Returns the XML contents as a single string
	 */
	public String getXmlContentsAsString () {
		String[] results = getXmlContents()
		String retval = ""
		String delim = ""
		results.each { String result ->
			retval = retval + delim + result
			delim = "\n\n"
		}
		return retval
	}
}
