package veracode

/**
 * Business Criticality enumeration for the Veracode API
 */
public enum BusinessCriticality {
	VERY_HIGH('Very High'),
	HIGH('High'),
	MEDIUM('Medium'),
	LOW('Low'),
	VERY_LOW('Very Low')
	
	final String name
	
	private BusinessCriticality(String name) {
		this.name = name
	}
}
