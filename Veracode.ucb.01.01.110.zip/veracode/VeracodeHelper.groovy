package veracode

import java.awt.font.TextLine.Function;

import com.ibm.issr.core.log.Logger;

/**
 * This is a helper class for working with the Veracode class library.  This is a singleton class.
 * @author ltclark
 *
 */
class VeracodeHelper {
	static private VeracodeHelper instance = new VeracodeHelper();
	
	public static VeracodeHelper getInstance() {
		return instance;
	}
	
	/**
	 * Use this helper function to call a Veracode function(s) with error handling.
	 * @param theCall
	 */
	public void callVeracodeFunctionWithErrorHandling( Closure theCall ) {
		theCall()
	}
	
	/**
	 * Converts an XML string into a DOM (Document Object Model tree).  Throws appropriate exceptions.
	 * @param xml The input string.
	 * @return Returns an XmlResult which contains both the XML String and the DOM.
	 */
	public convertXmlToDom( String xml ) {
		return new XmlResult(xml, new XmlSlurper().parseText( xml ))
	}
	
	/**
	 * Checks the result DOM for embedded error messages.  Throws exception on error.
	 * @param functionLabel The name and/or description of the function called, such as "createApp()"
	 * @param resultDom The result DOM
	 */
	public void testResultDomForErrors( String functionLabel, XmlResult xmlResult ) {
		if (xmlResult.isErrorResult()) {
			throw new VeracodeError("${functionLabel} returned '${xmlResult.getErrorMsg()}'", xmlResult, xmlResult.getErrorMsg())
		}
	}
}
