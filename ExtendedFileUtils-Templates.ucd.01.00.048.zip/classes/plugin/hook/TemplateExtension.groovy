package plugin.hook

import org.apache.velocity.VelocityContext

/**
 * Base class for a custom groovy extension which extends the behavior of the template.
 * An instance of this class is available to the templates as the name 'templateExtension'.
 * @author ltclark
 *
 */
abstract class TemplateExtension {
	/**
	 * This function can modify the Velocity Context and is called just before the template engine
	 * is called.  For example, this can define additional variables in the Velocity context.
	 * Some useful context functions are ... 'boolean containsKey(Object key)' tests to see if the key (aka variable name)
	 * is defined in the context.  'Object get(String key)' returns the value of the key/variable name.
	 * 'Object[] getKeys()' returns the list of context keys (aka variables). 'Object put(String key, Object value)'
	 * defines a context key/variable.  See the javadoc for Apache VelocyContext for additional details.
	 * @param context
	 */
	abstract void setupTemplateContext( VelocityContext context )
}
