package plugin

import com.ibm.issr.core.log.Logger
import com.ibm.issr.template.ApplyDataFilesToTemplateImplementation

class apply_json_to_template extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new apply_json_to_template()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}

	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		
		// Display a summary of what this plugin is going to do
		Logger.info "Apply JSON to Template..."
		def templateFile = retrieveAndDisplayInProp("templateFile")
		def outputFile = retrieveAndDisplayInProp("outputFile")
		def jsonFile = retrieveAndDisplayInProp("jsonFile")
		super.displayParameters()

		ApplyDataFilesToTemplateImplementation.applyJsonToTemplate( templateFile, jsonFile, outputFile )
		
	}

}
