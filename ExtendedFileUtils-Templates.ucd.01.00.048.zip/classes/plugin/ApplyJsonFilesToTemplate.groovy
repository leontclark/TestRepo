package plugin

import com.ibm.issr.core.log.Logger
import com.ibm.issr.template.ApplyDataFilesToTemplateImplementation

class ApplyJsonFilesToTemplate extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new ApplyJsonFilesToTemplate()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}

	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		
		// Display a summary of what this plugin is going to do
		Logger.info "Apply JSON Files to Template..."
		def templateFile = retrieveAndDisplayInProp("templateFile")
		def outputFile = retrieveAndDisplayInProp("outputFile")
		def jsonFiles = retrieveAndDisplayInProp("jsonFiles")
		def inputProperties = retrieveAndDisplayInProp("inputProperties")
		def groovyScript = retrieveAndDisplayInProp("groovyScript")
		def groovyScriptClassname = retrieveAndDisplayInProp("groovyScriptClassname")
		super.displayParameters()

		ApplyDataFilesToTemplateImplementation.applyDataFilesToTemplate( templateFile, jsonFiles, inputProperties, outputFile, groovyScript, groovyScriptClassname )
		
	}

}
