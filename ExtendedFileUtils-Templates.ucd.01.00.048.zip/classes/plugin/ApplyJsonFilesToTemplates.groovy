package plugin

import com.ibm.issr.core.log.Logger
import com.ibm.issr.template.ApplyDataFilesToTemplateImplementation

class ApplyJsonFilesToTemplates extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new ApplyJsonFilesToTemplates()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}

	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		
		// Display a summary of what this plugin is going to do
		Logger.info "Apply JSON Files to Template..."
		def templates = retrieveAndDisplayInProp("templates")
		def jsonFiles = retrieveAndDisplayInProp("jsonFiles")
		def inputProperties = retrieveAndDisplayInProp("inputProperties")
		def groovyScript = retrieveAndDisplayInProp("groovyScript")
		def groovyScriptClassname = retrieveAndDisplayInProp("groovyScriptClassname")
		super.displayParameters()
		
		// Translate templates from JSON to a list
		List templateList = new groovy.json.JsonSlurper().parseText(templates)

		ApplyDataFilesToTemplateImplementation.applyDataFilesToTemplates( templateList, jsonFiles, inputProperties, groovyScript, groovyScriptClassname )
		
	}

}
