package plugin

/**
 * Launch a groovy script after dynamically setting the classpath.
 * Normally, you set the classpath for an UrbanCode Plugin groovy script in plugin.xml as the '-cp'
 * parameter to calling groovy.
 * However, if the classpath has too many entries, the resulting command line string is too
 * long and the call fails.  This addresses the problem by dynamically setting groovy's classpath
 * and then calling the groovy script.
 * Parameters:
 * 	args[0] is the name of the directory that contains all of the jars that need to be added
 *		to the classpath.  This function finds *.jar in this directory and adds them (one by one)
 *		to the classpath.
 *	args[1] is the name of the groovy script to call.  Use package notation, such as "com.test.Script"
 *		and not directory notation (such as com/test/Script).
 * @author ltclark
 *
 */
class LauncherWithClasspath {

	static main(java.lang.String[] args) {
		// Dynamically add ALL of the jar files in the lib folder (args[0]) to the classpath
//		LauncherWithClasspath.class.classLoader.rootLoader.addURL(new File(args[0]+"/..").toURI().toURL())
		new File(args[0]).eachFile { File file ->
			if (file.isFile() && file.name.toLowerCase().endsWith(".jar")) {
//				println "adding ${file.toURI().toURL()}"
				LauncherWithClasspath.class.classLoader.rootLoader.addURL(file.toURI().toURL())
			}
		}
		
		// Call the regular groovy script
		LauncherWithClasspath.class.classLoader.loadClass(args[1], true).main( args )
	}

}
