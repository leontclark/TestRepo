package com.ibm.issr.template

import groovy.json.JsonOutput

import org.apache.velocity.Template
import org.apache.velocity.VelocityContext
import org.apache.velocity.app.Velocity

import plugin.hook.TemplateExtension

import com.ibm.issr.core.dynamicgroovy.AdhocGroovyClassLoader
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.properties.PropertyHelper
import com.ibm.issr.template.runtime.TemplateHelper
import com.ibm.issr.template.xml.NodeChildWrapper

/**
 * This is the implementation of the 'apply_json_to_template' plugin groovy step.
 * @author ltclark
 *
 */
public class ApplyDataFilesToTemplateImplementation {
	
	/**
	 * Apply a set of input DOMs (Document Object Models) and Properties to a Velocity template sending the merged
	 * result to the 'outputWriter';.  Note that Velocity.init()
	 * must be called before calling this function.
	 * @param outputWriter This writer is called to output the merged result.  Common implementations use either a StringWriter or FileWriter.
	 * @param template This is a loaded (in memory) Velocity template.  It may be loaded from a file, a string or ...?
	 * @param namedSourceDoms This is a Map of named input object models (DOMs).  The key is the context name to 
	 * put into the Template engine.  The value is any class.  The intent is that each entry in this list is a loaded
	 * JSON, XML, ... data source.
	 * @param inputProperties This is a map of additional context properties.  The key is the context name.  The value is any class instance.
	 * This may be null.
	 * @param templateExtension This is an optional (may be null) extension to the template context.  This is generally dynamically loaded
	 * groovy code which extends the engine.
	 */
	public static void applyTemplate( Writer outputWriter, Template template, Map namedSourceDoms, Map inputProperties, TemplateExtension templateExtension ) {
		// Define the velocity context
		VelocityContext context = new VelocityContext()
		
		// add our 'helper' class to the context
		TemplateHelper helper = new TemplateHelper()
		context.put( "helper", helper)

		// add the DOMs to the context
		namedSourceDoms.each { String key, def value ->
			context.put(key, value)
		}		
		
		// Add the properties to the context
		if (inputProperties) {
			inputProperties.each { String key, def value ->
				context.put(key, value)
			}
		}
		
		// If there is a templateExtension, add it to the context and call its setup function 
		if (templateExtension) {
			context.put( 'templateExtension', templateExtension )
			templateExtension.setupTemplateContext( context )
		}
		
		// Apply the Template!!
		template.merge( context, outputWriter )
	}
	
	/**
	 * Apply one or more JSON files to a Velocity Template.
	 * @param templateFile The name of the velocity template file.
	 * @param dataFiles The list of input files in a 'property file' format where, for the lines,
	 * 'boundVariableName=filename[,xml]', such as 'sampleJson=sample.json'.  If there the name ends with ",xml", then
	 * the file is an XML file, otherwise it is a json file.
	 * @param inputProperties A list of additional string parameters to define for the velocity template.
	 * The syntax follows the 'property file' format where, for the lines,
	 * 'jsonBoundVariableName=value', such as 'sampleProp=abc'.
	 * @param outputFile The name of the output file.
	 * @param groovyScript Body of the dynamic groovy script code to use.
	 * @param groovyScriptClassname The name of the groovy script class.
	 */
	public static void applyDataFilesToTemplate( String templateFile, String dataFiles, String inputProperties, String outputFile, String groovyScript, String groovyScriptClassname ) {
		List templates = [["templateFilename":templateFile, "outputFilename":outputFile]]
		ApplyDataFilesToTemplateImplementation.applyDataFilesToTemplates(templates, dataFiles, inputProperties, groovyScript, groovyScriptClassname)
	}
	
	/**
	 * Apply one or more JSON files to a Velocity Template.
	 * @param templates This is a List of templates to apply.  Each entry is a Map containing 'String templateFilename'
	 * and 'String outputFilename' which are the names of the input template and the output file respectively.
	 * @param dataFiles The list of input files in a 'property file' format where, for the lines,
	 * 'boundVariableName=filename[,xml]', such as 'sampleJson=sample.json'.  If there the name ends with ",xml", then
	 * the file is an XML file, otherwise it is a json file.
	 * @param inputProperties A list of additional string parameters to define for the velocity template.
	 * The syntax follows the 'property file' format where, for the lines,
	 * 'jsonBoundVariableName=value', such as 'sampleProp=abc'.
	 * @param groovyScript Body of the dynamic groovy script code to use.
	 * @param groovyScriptClassname The name of the groovy script class.
	 */
	public static void applyDataFilesToTemplates( List templates, String dataFiles, String inputProperties, String groovyScript, String groovyScriptClassname ) {
		
		Logger.debug "Called the templates function"
		
		Velocity.init()
		
		// Load the dynamic groovy script
		TemplateExtension sharedTemplateExtension = null
		if (groovyScript || groovyScriptClassname) {
			sharedTemplateExtension = AdhocGroovyClassLoader.getInstance().loadAdhocGroovyClass(groovyScript, groovyScriptClassname).newInstance()
		}
		
		// Load the json properties and then the actual json files
		def namedSourceDoms = [:]
		Properties jsonProperties = PropertyHelper.convertStringToProperties(dataFiles)
		jsonProperties.each { String propertyName, String propertyValue ->
			// Syntax of propertyValue is 'filename[,flags]'.  Separate the filename from the optional flags
			def splitValues = propertyValue.split(",")
			String filename = splitValues[0].trim()
			boolean isXml = false
			if (splitValues.length > 1) {
				// process the flags - currently only flag is xml
				if (splitValues[1].trim().equalsIgnoreCase("xml")) {
					isXml = true
				}
			}
			if (isXml) {
				def xmlData = new XmlSlurper().parseText( new File(filename).getText() )
				namedSourceDoms[propertyName] = new NodeChildWrapper(xmlData)
			} else {
				def jsonData = new groovy.json.JsonSlurper().parseText( JsonHelper.removeCommentLines(new File(filename).getText()) )
				namedSourceDoms[propertyName] = jsonData
			}
		}
		
		// Load the input properties into a map
		Properties additionalProperties = PropertyHelper.convertStringToProperties(inputProperties)

		templates.each { Map entry ->
			String templateFile = entry.templateFilename
			String outputFile = entry.outputFilename
			TemplateExtension templateSpecificExtension = sharedTemplateExtension
			if (entry.containsKey('groovyScriptFilename')) {
				// This template has a custom groovy script file to use instead of the shared template.
				String scriptClassname = entry.groovyScriptFilename
				String groovyExtension = '.groovy'
				if (scriptClassname.toLowerCase().endsWith(groovyExtension)) {
					scriptClassname = scriptClassname.substring(0, scriptClassname.length()-groovyExtension.length())
				}
				templateSpecificExtension = AdhocGroovyClassLoader.getInstance().loadAdhocGroovyClass("", scriptClassname).newInstance()
			}
			
			Logger.info "Applying template '${templateFile}'"
			
			// Load the template from the templateFile
			Template template = Velocity.getTemplate(templateFile)
			
			// Merge the template to a file writer
			FileWriter outputWriter = new FileWriter(outputFile)
	//		StringWriter sw = new StringWriter()
			applyTemplate(outputWriter, template, namedSourceDoms, additionalProperties, templateSpecificExtension)
			outputWriter.close()
			
			Logger.debug "Contents after applying template '${templateFile}': " + (new File(outputFile)).text
		}
	}
	
	
	/**
	 * Apply a JSON file to a Velocity Template.
	 * @param templateFile The name of the file containing the Velocity Template.
	 * @param jsonFile The name of the file containing the JSON data.
	 * @param outputFile The name of the output file.
	 */
	public static void applyJsonToTemplate( def templateFile, def jsonFile, def outputFile ) {
		
		Logger.debug "Called the template function"
		
		Velocity.init()
		
		// Load the json properties and then the actual json files
		def namedSourceDoms = [:]
		def jsonData = new groovy.json.JsonSlurper().parseText( JsonHelper.removeCommentLines(new File(jsonFile).getText()) )
		Logger.debug "Loaded JSON: " + JsonOutput.prettyPrint(JsonOutput.toJson(jsonData))
		namedSourceDoms['json'] = jsonData
		
		// There are no additional properties
		def additionalProperties = [:]

		// Load the template from the templateFile
		Template template = Velocity.getTemplate(templateFile)
		
		// Merge the template to a file writer
		FileWriter outputWriter = new FileWriter(outputFile)
//		StringWriter sw = new StringWriter()
		ApplyDataFilesToTemplateImplementation.applyTemplate(outputWriter, template, namedSourceDoms, additionalProperties, null)
		outputWriter.close()
		
		Logger.debug "Contents after applying template: " + (new File(outputFile)).text
	}
}
