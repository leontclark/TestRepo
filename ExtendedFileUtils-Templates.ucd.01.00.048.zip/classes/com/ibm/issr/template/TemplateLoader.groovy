package com.ibm.issr.template

import org.apache.velocity.Template
import org.apache.velocity.runtime.RuntimeServices
import org.apache.velocity.runtime.RuntimeSingleton


class TemplateLoader {
	/**
	 * Loads a Velocity template body from a String instead of a file.  You must call 
	 * Velocity.init() before calling this function.
	 * @param templateBody A string containing a velocity template.
	 * @param templateName The name of the template that Velocity uses when referring to this template.
	 * @return The loaded Velocity Template.
	 */
	public static Template loadTemplateFromString( String templateBody, String templateName ) {
		RuntimeServices runtimeServices = RuntimeSingleton.getRuntimeServices();
		StringReader reader = new StringReader(templateBody);
		Template template = new Template();
		template.setRuntimeServices(runtimeServices);
		
		/*
		 * The following line works for Velocity version up to 1.7
		 * For version 2, replace "Template name" with the variable, template
		 */
		template.setData(runtimeServices.parse(reader, templateName));
		
		template.initDocument();
		
		return template
	}
}
