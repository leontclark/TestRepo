package com.ibm.issr.template.xml

import groovy.util.slurpersupport.NodeChild;

/**
 * Unfortunately, when you use XmlSlurper with Velocity, velocity is unable
 * to leverage the dynamic groovy class behaviour of the nodes.  So, the resulting
 * nodes are pretty much impossible to use within Velocity.  Specifically, XmlSlurper
 * returns nodes of class type groovy.util.slurpersupport.NodeChild.  Velocity is unable
 * to navigate to child nodes.  This class wraps the NodeChild class into a more traditional
 * java style class which Velocity can use.
 * 
 * Note that NodeChildrenWrapper wraps NodeChildren.  In groovy 1.8, NodeChildren is a private class!!  It is public in newer versions of Groovy.
 * @author ltclark
 *
 */
class NodeChildWrapper {
	private NodeChild node;
	
	/**
	 * Constructor, which wraps a groovy NodChild.
	 */
	public NodeChildWrapper( NodeChild node ) {
		this.node = node
	}
	
	/**
	 * Returns the value of the named node attribute.
	 * @param attributeName The name of the attribute.
	 * @return The value.
	 */
	public String attribute( String attributeName ) {
		return node.attributes().get(attributeName)
	}
	
	/**
	 * Does the node have the named attribute?
	 */
	public boolean hasAttribute( String attributeName ) {
		return node.attributes().containsKey(attributeName)
	}
	
	/**
	 * Returns a children entry for all children with the matching node name.
	 * The children entry may have 0, 1 or multiple entries.
	 * @param nodeName The name of the child nodes.
	 */
	public NodeChildrenWrapper children( String nodeName ) {
		return new NodeChildrenWrapper(node[nodeName])
	}
	
	/**
	 * Does this node have any children with the given node name.
	 */
	public boolean hasChildren( String nodeName ) {
		return node[nodeName].size() > 0
	}
	
	/**
	 * Returns the text value of the first child that has the matching nodeName.
	 * If there is no matching child, then this returns the default value.
	 */
	public String getChildNodeText( String nodeName, String defaultValue='') {
		def children = node[nodeName]
		if (children.size() > 0) {
			return children[0].text()
		} else {
			return defaultValue
		}
	}
	
	/**
	 * toString returns the text of the node.
	 */
	public String toString() {
		return node.text()
	}
}
