package com.ibm.issr.template.xml

import groovy.util.slurpersupport.NodeChild
import groovy.util.slurpersupport.NodeChildren

/**
 * POJO java wrapper around the class groovy.util.slurpersupport.NodeChildren to
 * make that class work in Velocity (which it fails to do otherwise).
 * @author ltclark
 *
 */
class NodeChildrenWrapper {
	// The wrapped instance.  'nodeChildren' IS an instance of 'NodeChildren', BUT
	// UCD currently uses Groovy 1.8.8, where NodeChildren is a private class.  So,
	// nodeChildren can't be formally typed without throwing exceptions.  But, if it
	// is typed as just 'def', all of the NodeChildren functions are fully available, but
	// without strong typing.  Note that in newer versions of Groovy, NodeChildren is a
	// public class.
	private /* NodeChildren */ def nodeChildren
	
	/**
	 * Constructor which wraps the NodeChildren class instance.
	 */
	public NodeChildrenWrapper( /* NodeChildren */ def nodeChildren ) {
		this.nodeChildren = nodeChildren
	}
	
	/**
	 * Returns the number of nodes that are in this 'children' entry.
	 */
	public int size() {
		return nodeChildren.size()
	}
	
	/**
	 * Returns a collection of the child nodes (each in its NodeChildWrapper).
	 */
	public Collection nodes() {
		ArrayList retval = new ArrayList()
		nodeChildren.each { NodeChild child ->
			retval.add(new NodeChildWrapper(child))
		}
		return retval
	}
	
	/**
	 * Returns the first node in the list.
	 */
	public NodeChildWrapper node0() {
		return new NodeChildWrapper( nodeChildren[0] ) 
	}
}
