package com.ibm.issr.template.runtime

import java.lang.reflect.Array;

/**
 * This is a helper class for calling template functions.  It has helper functions,
 * such as getMember() which looks up a map member return a default value if undefined.
 * @author ltclark
 *
 */
class TemplateHelper {
	/**
	 * Looks up a 'member' data element from a map returning the defaultValue if the member
	 * isn't defined.
	 * @param map The map.
	 * @param memberName The name of the desired member element.
	 * @param defaultValue The default value to return if not found.
	 */
	public def getMember( def map, String memberName, def defaultValue ) {
		if (map.containsKey(memberName)) {
			return map[memberName]
		} else {
			return defaultValue
		}
	}
	
	/**
	 * Is there a member element with the given key name?
	 * @param map The map.
	 * @param memberName The name of the element to check.
	 * @return Boolean existence (true if exists).
	 */
	public boolean isMember( def map, String memberName ) {
		return (map.containsKey(memberName))
	}
	
	/**
	 * Does the map contain a member array named 'memberName'?
	 */
	public boolean isMemberArray( def map, String memberName ) {
		if (map.containsKey(memberName)) {
			def member = map[memberName]
			return (member instanceof AbstractList)
		}
		return false
	}
	
	/**
	 * Is the 'memberName' member of the map an array with at least one data entry?
	 */
	public boolean isMemberArrayWithData( def map, String memberName ) {
		if (isMemberArray(map,memberName)) {
			def arraySize = map[memberName].size()
			return (arraySize> 0)
		}
		return false
	}
	
	/**
	 * Returns the named child array.  Returns an empty array if it doesn't exist!!
	 */
	public def getMemberArray( def map, String memberName ) {
		if (isMemberArray(map,memberName)) {
			return map[memberName]
		} else {
			return []
		}
	}
}
