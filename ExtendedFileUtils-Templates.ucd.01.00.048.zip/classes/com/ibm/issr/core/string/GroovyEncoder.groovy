package com.ibm.issr.core.string

/**
 * This class encodes strings into values that can be used as Groovy/Java strings.
 * For example, this would convert "c:\temp" into "c:\\temp".  The resulting string
 * can be used as the value of a groovy string, such as [String s = "${encodedStrng}"].
 * @author ltclark
 *
 */
class GroovyEncoder {
	/**
	 * Encodes the original value into a string value that is suitable for use in
	 * a groovy string constant.  For example, this converts 'c:\temp' into 'c:\\temp'.
	 * @param originalValue The original (non-encoded) string.
	 * @return Returns the encoded string.
	 */
	public static String encodeString( String originalValue ) {
		String encodedValue = ""
		for (int i=0; i<originalValue.length(); ++i) {
			String letter = originalValue.substring(i,i+1)
			if (letter == "\\") {
				encodedValue = encodedValue + "\\\\"
			} else if (letter == '"') {
				encodedValue = encodedValue + '\\"'
			} else if (letter == "'") {
				encodedValue = encodedValue + "\\'"
			} else if (letter == "\n") {
				encodedValue = encodedValue + "\\n"
			} else if (letter == "\t") {
				encodedValue = encodedValue + "\\t"
			} else {
				encodedValue = encodedValue + letter
			}
		}
		return encodedValue
	}
}
