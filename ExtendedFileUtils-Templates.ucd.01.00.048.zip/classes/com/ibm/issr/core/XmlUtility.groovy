package com.ibm.issr.core

class XmlUtility {
	
	/**
	 * Escapes " ' & < and > as &quot;, &apos;, &quot;, &lt; and &gt. 
	 * @param orig
	 * @return Encoded XML string.
	 */
	public static String escapeXml( String orig ) {
		return orig.replaceAll("&", "&quot;").replaceAll("\"", "&quot;").replaceAll("'", "&apos;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
	}
}
