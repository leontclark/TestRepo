package com.ibm.issr.core.properties

/**
 * Helper class for working with Java Property 'files'.
 * @author ltclark
 *
 */
class PropertyHelper {
	/**
	 * Converts a String that contains property syntax (a=b on multiple lines) into Properties.
	 * @param propertyString The string that contains a Property formatted content.
	 * @return The Properties.
	 */
	public static Properties convertStringToProperties( String propertyString ) {
		Properties properties = new Properties()
		properties.load(new StringReader(propertyString))
		return properties
	}
}
