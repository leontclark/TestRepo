package com.ibm.issr.core.json

/**
 * JSON Helper functions
 * @author LeonClark
 *
 */
class JsonHelper {
	/**
	 * Removes comment lines from a multiple-line JSON string.
	 * A comment line is any line that starts with '//' or '#'.
	 * More specifically, it replaces comment lines with empty lines
	 * so that the original line numbering is preserved.
	 * @param jsonString Multiple line JSON string
	 * @return The json string with comment lines taken out.
	 */
	static String removeCommentLines( String jsonString ) {
		String bodyWithoutComments = ''
		
		jsonString.eachLine { line, count ->
			if (line.trim().startsWith('//') || line.trim().startsWith('#')) {
				// This is a comment line, replace with blank line
				bodyWithoutComments = bodyWithoutComments + "\n"
			} else {
				bodyWithoutComments = bodyWithoutComments + line + '\n'
			}
		}

		return bodyWithoutComments
	}
}
