package veracode

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.core.log.Logger;
import com.veracode.apiwrapper.wrappers.UploadAPIWrapper;

/**
 * This class provides normalized access to various Veracode UploadApi function calls.
 * @author ltclark
 *
 */
class VeracodeUploadApi extends LogTracingClass {
	private UploadAPIWrapper uploadWrapper
	VeracodeHelper veracodeHelper
	
	/**
	 * Constructor
	 * @param wrapper The underlying Veracode upload api handle.
	 */
	public VeracodeUploadApi( UploadAPIWrapper wrapper, String username, String password, String proxyHost, String proxyPort ) {
		this.uploadWrapper = wrapper
		if (proxyHost && proxyPort) {
			uploadWrapper.setUpProxy( proxyHost, proxyPort )
		}
		uploadWrapper.setUpCredentials( username, password )
		veracodeHelper = VeracodeHelper.getInstance()
	}
	
	/**
	 * Creates a new veracode build for the app.  Version must be a unique version string, such as a date/time stamp.
	 * Throws an exception if there is a problem.
	 * Returns the XmlResult
	 */
	public XmlResult createBuild( String app_id, String version ) {
		String xmlResult = ""
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			xmlResult = uploadWrapper.createBuild(app_id, version)
		}
		Logger.debug "createBuild returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "createBuild()", result
		return result
	}

	/**
	 * Creates an application return the corresponding XML DOM.  
	 * The only required parameters are the app_name and the business_criticality.
	 * Throws an exception if there is a problem.
	 * Returns the XmlResult
	 */
	public XmlResult createApp( String app_name, String description, String vendor_id, BusinessCriticality business_criticality, String policy, String business_unit, String business_owner, String business_owner_email, String teams, String origin, String industry, String app_type, String deployment_type, String web_application, String archer_app_name, String tags ) {
		String xmlResult = ""
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			xmlResult = uploadWrapper.createApp( app_name, description, vendor_id, business_criticality.name, policy, business_unit, business_owner, business_owner_email, teams, origin, industry, app_type, deployment_type, web_application, archer_app_name, tags )
		}
		Logger.debug "createApp returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "createApp()", result
		return result
	}
	
	/**
	 * Deletes the identified application return the xml result.
	 */
	public XmlResult deleteApp( String app_id ) {
		String xmlResult = ""
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			xmlResult = uploadWrapper.deleteApp(app_id)
		}
		Logger.debug "deleteApp returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "deleteApp()", result
		return result
	}
	
	/**
	 * Call getAppList() which returns the list of applications.
	 * @param include_user_info If true, then also returns application permission information for the actively authenticated user.
	 * @return Returns the XML (as a string and DOM).
	 */
	public XmlResult getAppList( boolean include_user_info ) {
		String xmlResult = ""
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			if (include_user_info) {
				xmlResult = uploadWrapper.getAppList("true")
			} else {
				xmlResult = uploadWrapper.getAppList()
			}
		}
		Logger.debug "getAppList returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "getAppList()", result
		return result
	}

		
	/**
	 * Returns the list of of sandboxes for the application by calling the veracode getSandboxList() API call.
	 * @param app_id Application ID
	 * @return Returns the XML (as a string and DOM).
	 */
	public XmlResult getSandboxList( String app_id ) {
		String xmlResult = ""
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			xmlResult = uploadWrapper.getSandboxList(app_id)
		}
		Logger.debug "getSandboxList returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "getSandboxList()", result
		return result

	}
	
	
/**
 * Creates a new sandbox.  Throws exception on error, such as sandbox name already exists.
 * @param app_id Application ID
 * @param sandbox_name The name of the new sandbox.
 * @return Returns the ID of the new sandbox.
 */
public String createSandbox( String app_id, String sandbox_name ) {
	String xmlResult = ""
	veracodeHelper.callVeracodeFunctionWithErrorHandling {
		xmlResult = uploadWrapper.createSandbox(app_id, sandbox_name)
	}
	Logger.debug "createSandbox returned ...\n" + xmlResult
	XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
	veracodeHelper.testResultDomForErrors "getSandboxList()", result
	
	return result.xmlDom.sandbox[0].@sandbox_id
}

	/**
	 * Returns the Application ID for the named application or null if it isn't found.
	 */
	public String getAppId( String app_name ) {
		String retval = null
		def appList = getAppList( false ).xmlDom
		// iterate the listed app's looking for a match
		appList.app.each {
			if (it.@app_name == app_name) {
				retval = it.@app_id
			}
		}
		return retval
	}
	
	/**
	 * Is the preScan complete?
	 * @param app_id Required application ID.
	 * @param build_id Optional build id.  A String that represents an Integer value. Defaults to the most recent build.
	 * @param sandbox_id Optional sandbox id
	 * @return Returns a map where xmlResult is the XML and isComplete is the boolean completion value.
	 */
	public isPreScanComplete( String app_id, String build_id, String sandbox_id ) {
		Boolean isComplete = true
		String xmlResult = ""
		if (sandbox_id) {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}', '${build_id}', '${sandbox_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id, build_id, sandbox_id)
		} else if (build_id) {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}', '${build_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id, build_id)
		} else {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id)
		}
		Logger.debug "getPreScanResults() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		if (result.isErrorResult() && result.getErrorMsg().startsWith("Prescan results not available")) {
			isComplete = false
		} else {
			veracodeHelper.testResultDomForErrors "getPreScanResults()", result
		}
		return [ xmlResult : result, isComplete : isComplete ]
	}

	/**
	 * Fetches the results of the pre-scan.
	 * @param app_id Required application ID.
	 * @param build_id Optional build id.  A String that represents an Integer value. Defaults to the most recent build.
	 * @param sandbox_id Optional sandbox id
	 * @return Returns the result xml.
	 */
	public XmlResult getPreScanResults( String app_id, String build_id, String sandbox_id ) {
		String xmlResult = ""
		if (sandbox_id) {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}', '${build_id}', '${sandbox_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id, build_id, sandbox_id)	
		} else if (build_id) {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}', '${build_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id, build_id)	
		} else {
			Logger.debug "Calling uploadWrapper.getPreScanResults('${app_id}')"
			xmlResult = uploadWrapper.getPreScanResults(app_id)	
		}
		Logger.debug "getPreScanResults() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "getPreScanResults()", result
		return result
	}
	
	/**
	 * Begins a Scan.  Note that this function supports dry runs - where dry run data is set into
	 * the DryRunHelper class.  When dry run data is set, this function uses that data as the 
	 * returned XML without actually calling the VeraCode api.
	 * @param app_id The applicaiton ID, which is required.
	 * @param modules Comma-separated list of module IDs. Validates against the IDs of existing modules for the most recent build. 
	 * Requires either this parameter or the scan_all_top_level_modules parameter.
	 * @param scan_all_top_level_modules If true than all top level modules are scanned.  If false, then
	 * the 'modules' list MUST be provided instead.
	 * @param sandbox_id Optional sandbox id
	 * @return Returns the result xml.
	 */
	public XmlResult beginScan( String app_id, String modules, Boolean scan_all_top_level_modules, String sandbox_id ) {
		String xmlResult = ""
		if (DryRunHelper.instance.dryRunXmlResults) {
			Logger.debug("Calling uploadWrapper.beginScan() in 'DRY RUN' mode.")
			xmlResult = DryRunHelper.instance.dryRunXmlResults
		} else {
			if (sandbox_id) {
				Logger.debug( "Calling uploadWrapper.beginScan('${app_id}', '${modules}', '${scan_all_top_level_modules.toString()}', ${sandbox_id})")
				xmlResult = uploadWrapper.beginScan(app_id, modules, scan_all_top_level_modules.toString(), sandbox_id)
			} else {
				Logger.debug( "Calling uploadWrapper.beginScan('${app_id}', '${modules}', '${scan_all_top_level_modules.toString()}')")
				xmlResult = uploadWrapper.beginScan(app_id, modules, scan_all_top_level_modules.toString())
			}
		}
		Logger.debug "beginScan() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "beginScan()", result
		return result
	}

	/**
	 * Begins a preScan.
	 * @param app_id The applicaiton ID, which is required.
	 * @param sandbox_id Optional sandbox id
	 * @param auto_scan If true, then automatically start a scan after the prescan is complete.
	 * @return Returns the result xml.
	 */
	public XmlResult beginPreScan( String app_id, String sandbox_id, Boolean auto_scan ) {
		String xmlResult = ""

		if (auto_scan) {
			Logger.debug( "Calling uploadWrapper.beginPreScan('${app_id}', '${sandbox_id}', '${auto_scan.toString()}' )")
			xmlResult = uploadWrapper.beginPreScan(app_id, sandbox_id, auto_scan.toString() )
		} else if (sandbox_id) {
			Logger.debug( "Calling uploadWrapper.beginPreScan('${app_id}', '${sandbox_id}' )")
			xmlResult = uploadWrapper.beginPreScan(app_id, sandbox_id )
		} else {
			Logger.debug( "Calling uploadWrapper.beginPreScan('${app_id}' )")
			xmlResult = uploadWrapper.beginPreScan(app_id )
		}
		Logger.debug "beginPreScan() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "beginPreScan()", result
		return result
	}
	
	/**
	 * Extracts and returns the build_id from the XmlResult from calling beginPreScan().
	 */
	public String extractBuildIdFromBeginPreScanResults( XmlResult xmlResult ) {
		xmlResult.xmlDom.@build_id.toString()
	}

	/**
	 * Uploads a file to an existing build of an application. You cannot upload to a build that is in a pre-scan state.
	 * This call creates a build if one does not already exist or if the most recent build has a published static scan, 
	 * therefore, it is not necessary to also call createbuild.do as part of the Upload API workflow. 
	 * @param app_id The application ID, which is required.
	 * @param file The filename (relative or absolute), which is required.
	 * @param sandbox_id Optional sandbox id
	 * @param save_as Optional - The new file name for the uploaded file.
	 * @return Returns the result xml.
	 */
	public XmlResult uploadFile( String app_id, String file, String sandbox_id, String save_as ) {
		String xmlResult = ""
		
		// convert the file to an absolute filename
		file = new File(file).getAbsolutePath()
		
		veracodeHelper.callVeracodeFunctionWithErrorHandling {
			if (save_as) {
				Logger.debug("Calling uploadWrapper.uploadFile('${app_id}', '${file}', '${sandbox_id}', '${save_as}')")
				xmlResult = uploadWrapper.uploadFile(app_id, file, sandbox_id, save_as)
			} else if (sandbox_id) {
				Logger.debug("Calling uploadWrapper.uploadFile('${app_id}', '${file}', '${sandbox_id}')")
				xmlResult = uploadWrapper.uploadFile(app_id, file, sandbox_id )
			} else {
				Logger.debug("Calling uploadWrapper.uploadFile('${app_id}', '${file}' )")
				xmlResult = uploadWrapper.uploadFile(app_id, file )
			}
		}
		Logger.debug "uploadFile returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "uploadFile()", result
		return result
	}
	
	/**
	 * Uploads a list of files to an application.  You cannot upload to a build that is in a pre-scan state.
	 * This call creates a build if one does not already exist or if the most recent build has a published static scan, 
	 * therefore, it is not necessary to also call createbuild.do as part of the Upload API workflow. 
	 * @param app_id The application ID, which is required.
	 * @param baseDir Required - the base directory to which the includes and excludes are relative to.
	 * @param includes A new line separated list of file patterns to include.
	 * @param excludes A new line separated list of file patterns to exclude.
	 * @param sandbox_id Optional - The new file name for the uploaded file.
	 * @return Returns an XML result which contains nested xml results for all of the actual files that were found.
	 */
	public XmlResult uploadFiles( String app_id, String baseDir, String includes, String excludes, String sandbox_id ) {
		XmlResult result = null
		
		def ant = new AntBuilder()
		def scanner = ant.fileScanner {
			fileset(dir:baseDir) {
				includes.split('[\r\n]').each {
					if (it && it.trim().length() > 0) {
						include(name: it.trim())
					}
				}
				excludes?.split('[\r\n]')?.each {
					if (it && it.trim().length() > 0) {
						exclude(name: it.trim())
					}
				}
			}
		}
		
		for (f in scanner) {
			String absPath = f.getAbsolutePath()
			Logger.info "Uploading ${absPath} to VeraCode"
			result = uploadFile( app_id, f.getAbsolutePath(), sandbox_id, null ).setNestedResult( result )
		}

		return result		
	}
}
