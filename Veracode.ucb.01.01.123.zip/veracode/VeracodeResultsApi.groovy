package veracode

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.core.log.Logger;
import com.veracode.apiwrapper.wrappers.ResultsAPIWrapper;
import com.veracode.apiwrapper.wrappers.ResultsAPIWrapper;

/**
 * This class provides normalized access to various Veracode UploadApi function calls.
 * @author ltclark
 *
 */
class VeracodeResultsApi extends LogTracingClass {
	private ResultsAPIWrapper resultsWrapper
	VeracodeHelper veracodeHelper
	
	/**
	 * Constructor
	 * @param wrapper The underlying Veracode upload api handle.
	 */
	public VeracodeResultsApi( ResultsAPIWrapper wrapper, String username, String password, String proxyHost, String proxyPort ) {
		this.resultsWrapper = wrapper
		if (proxyHost && proxyPort) {
			resultsWrapper.setUpProxy( proxyHost, proxyPort )
		}
		resultsWrapper.setUpCredentials( username, password )
		veracodeHelper = VeracodeHelper.getInstance()
	}
	
	/**
	 * Compiles a detailed list of applications and statuses, including all the application and build profile data.
	 * @return Returns the result xml.
	 */
	public XmlResult getAppBuilds() {
		String xmlResult = ""
		
		Logger.debug "Calling resultsWrapper.getAppBuilds()"
		xmlResult = resultsWrapper.getAppBuilds()
		
		Logger.debug "getAppBuilds() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "getAppBuilds()", result
		return result
	}
	
	/**
	 * Did the scan pass??  Note that this function supports dry runs - where dry run data is set into
	 * the DryRunHelper class.  When dry run data is set, this function uses that data as the
	 * returned XML without actually calling the VeraCode api.
	 * @param build_id Requred build id.  A String that represents an Integer value.
	 * @return Returns a map where xmlResult is the XML and passed is the boolean completion value.
	 */
	public didTheScanPass( String build_id ) {
		Boolean passed = true
		String xmlResult = ""
		
		if (DryRunHelper.instance.dryRunXmlResults) {
			Logger.debug("Calling resultsWrapper.summaryReport() in 'DRY RUN' mode.")
			xmlResult = DryRunHelper.instance.dryRunXmlResults
		} else {
			Logger.debug "Calling resultsWrapper.summaryReport('${build_id}')"
			xmlResult = resultsWrapper.summaryReport(build_id)
		}
		
		Logger.debug "getScanResults() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		
		veracodeHelper.testResultDomForErrors "isScanComplete()", result
		
		// Test for error values
		String policy_compliance_status = result.xmlDom.policy_compliance_status
		String policy_rules_status = result.xmlDom.@policy_rules_status
		if (policy_compliance_status.equalsIgnoreCase("Did Not Pass") || policy_rules_status.equalsIgnoreCase("Did Not Pass")) {
			passed = false
		}
		
		return [ xmlResult : result, passed : passed ]
	}

	/**
	 * Is the scan complete??  Note that this function supports dry runs - where dry run data is set into
	 * the DryRunHelper class.  When dry run data is set, this function uses that data as the 
	 * returned XML without actually calling the VeraCode api.
	 * @param build_id Requred build id.  A String that represents an Integer value.
	 * @return Returns a map where xmlResult is the XML and isComplete is the boolean completion value.
	 */
	public isScanComplete( String build_id ) {
		Boolean isComplete = true
		String xmlResult = ""
		
		if (DryRunHelper.instance.dryRunXmlResults) {
			Logger.debug("Calling resultsWrapper.summaryReport() in 'DRY RUN' mode.")
			xmlResult = DryRunHelper.instance.dryRunXmlResults
		} else {
			Logger.debug "Calling resultsWrapper.summaryReport('${build_id}')"
			xmlResult = resultsWrapper.summaryReport(build_id)
		}
		
		Logger.debug "getScanResults() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		
		if (result.isErrorResult() && result.getErrorMsg().equalsIgnoreCase("No report available.")) {
			isComplete = false
		} else {
			veracodeHelper.testResultDomForErrors "isScanComplete()", result
		}
		return [ xmlResult : result, isComplete : isComplete ]
	}

	/**
	 * Fetches the results of the scan.
	 * @param build_id Requred build id.  A String that represents an Integer value.
	 * @return Returns the result xml.
	 */
	public XmlResult getScanResults( String build_id ) {
		String xmlResult = ""
		
		Logger.debug "Calling resultsWrapper.summaryReport('${build_id}')"
		xmlResult = resultsWrapper.summaryReport(build_id)
		
		Logger.debug "getScanResults() returned ...\n" + xmlResult
		XmlResult result = veracodeHelper.convertXmlToDom(xmlResult)
		veracodeHelper.testResultDomForErrors "getScanResults()", result
		return result
	}
}
