package veracode;

/**
 * This is an exception that is thrown when an 'error' code is returned from
 * a Veracode API call as an XML string.
 * @author ltclark
 *
 */
public class VeracodeError extends Exception {
	private static final long serialVersionUID = 3205090104203708268L;

	XmlResult xmlResult
	String errorValue
	
	/**
	 * Constructor
	 * @param description The standard exception description
	 * @param xmlResult The XML String (as string and DOM) that contained the error message.
	 * @param errorValue The nested error message in the DOM.
	 */
	public VeracodeError( String description, XmlResult xmlResult, String errorValue ) {
		super(description)
		this.xmlResult = xmlResult
		this.errorValue = errorValue
	}
}
