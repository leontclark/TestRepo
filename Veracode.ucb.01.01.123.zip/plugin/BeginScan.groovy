package plugin

import veracode.BusinessCriticality;
import veracode.DryRunHelper;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class BeginScan extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String sandbox_id
	private String modules
	private Boolean scan_all_top_level_modules
	private String build_idProperty
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new BeginScan()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		sandbox_id = inProps.sandbox_id
		modules = inProps.modules
		scan_all_top_level_modules = false
		if (inProps.scan_all_top_level_modules && inProps.scan_all_top_level_modules.equalsIgnoreCase("true")) {
			scan_all_top_level_modules = true
		}
		build_idProperty = inProps.build_idProperty
		
		// Summarize parameters
		Logger.info "Calling BeginScan"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Begin the prescan
		DryRunHelper.instance.dryRunXmlResults = super.dryRun
		XmlResult xmlResult = uploadApi.beginScan(appId, modules, scan_all_top_level_modules, sandbox_id)
		setOutputProperty(xmlResult)
		if (build_idProperty) {
			outProps.put(build_idProperty, xmlResult.xmlDom.@build_id.toString())
		}
		
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   modules='${modules}'"
		Logger.info "   scan_all_top_level_modules=${scan_all_top_level_modules}"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   build_idProperty='${build_idProperty}'"
		super.displayParameters();
	}
	
	
}
