package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeHelper;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class CreateApp extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String description
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new CreateApp()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		description = inProps.description
		
		// Summarize parameters
		Logger.info "Calling CreateApp"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		XmlResult xmlResult = uploadApi.createApp(appName, description, "", BusinessCriticality.MEDIUM, "", "", "", "", "IT- Film & West Coast Television I - MoveCommand", "", "", "", "", "", "", "")
		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   description='${description}'"
		super.displayParameters();
	}
	
	
}
