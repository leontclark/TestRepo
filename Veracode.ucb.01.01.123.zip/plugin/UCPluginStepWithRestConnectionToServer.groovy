package plugin

import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.client.DeployClient

/**
 * <p>This is an optional shared base class for implementing UrbanCode plugin steps which AUTOMATICALLY
 * establish a REST connection back to the calling server!!  Use this base class instead of {@link UCPluginStepImplementation}
 * to add the additional REST logic.
 * </p>
 * <p>Note that the REST connection is established on demand.  So, if the step never
 * makes a server REST call, the connection isn't created.  However, if the step
 * makes multiple server REST calls, only a single connection is created.
 * </p>
 * @author ltclark
 *
 */
abstract class UCPluginStepWithRestConnectionToServer extends UCPluginStepImplementation {
	/**
	 * This is a {@link RestClient} handle to the server that called the agent.
	 */
	private RestClient theServerRestClient = null
	private boolean connectionAttempted = false

	@Override
	void performStep( java.lang.String[] args, Closure executionImplementation ) {
		// Remember the parent closure
		super.performStep(args) { // Call the nested implementation
			executionImplementation() }

	}

	/**
	 * Returns the {@link RestClient} handle to the server that called the agent.  This
	 * throws an exception if there is a problem. 
	 */
	public RestClient getServerRestClient() {
		if (connectionAttempted && (! theServerRestClient)) {
			Logger.debug "UCPluginStepImplementation.getServerRestClient() - attempt to access RestClient after connection already failed"
			throw new Exception( "Attempting to connect to UrbanCode Server, but previous attempts at connecting already failed")
		}
		if (! connectionAttempted) {
			// CREATE THE CONNECTION
			Logger.trace "UCPluginStepWithRestConnectionToServer.getServerRestClient() is opening a REST connection to the server"

			connectionAttempted = true;

			// get server name
			def ucdServerUrl = this.myRestServerUrl
			// use automatic token based authentication
			def ucdUsername = this.myRestServerTokenUsername
			def ucdPassword = this.myRestServerTokenPassword


			// Build the UCD REST client session
			theServerRestClient = new RestClient();
			theServerRestClient.openConnection( ucdServerUrl, ucdUsername, ucdPassword );
		}

		return theServerRestClient
	}

	/**
	 * Sets a Property value for a Process Request.  If you set properties the default way (by adding entries to outProps),
	 * they are linked to the specific process step and must be referenced using the steps name.  If someone changes the name
	 * of the process step, then any downstream references to the property are broken.  It is MUCH more stable and easy to
	 * use if the property value is set against the runtime Process Request instead of the runtime step.  Then you can simply
	 * reference the property without needing the step name.  To do so requires a Rest call to the server.  Simply call this
	 * function to set a Process Request property from within the implementation of a Plugin Step.
	 * @param processRequestId This is the ID of the process.  This must be provided.  It may be an Application, Component or Generic process.
	 * Note that some common ways to get to the 
	 * process request is the property request.id, which is the ID of the current process and parentResource.id which
	 * is the id of the parent process (if the process is nested, such as an Component Process called from an Application Process).
	 * @param processPropertyName The name of the property.
	 * @param processPropertyValue The value of the property.
	 * @param secure Set to true to make the property a secure property.  This defaults to false.
	 */
	void setProcessRequestProperty( String processRequestId, String processPropertyName, String processPropertyValue, boolean secure = false ) {
		DeployClient deployClient = new DeployClient(serverRestClient)
		deployClient.setProcessRequestProperty( processRequestId, processPropertyName, processPropertyValue, secure )
	}
}
