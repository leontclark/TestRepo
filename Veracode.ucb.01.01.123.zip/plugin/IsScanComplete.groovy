package plugin

import veracode.BusinessCriticality;
import veracode.DryRunHelper;
import veracode.VeracodeResultsApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class IsScanComplete extends CoreVeraCodePlugin {
	// Arguments
	private String build_id
	private String completeProperty
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new IsScanComplete()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		build_id = inProps.build_id
		completeProperty = inProps.completeProperty
		
		// Summarize parameters
		Logger.info "Calling IsScanComplete"
		displayParameters()
		
		VeracodeResultsApi resultsApi = new VeracodeResultsApi(new ResultsAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// execute
		DryRunHelper.instance.dryRunXmlResults = super.dryRun
		def result = resultsApi.isScanComplete(build_id)
		setOutputProperty(result.xmlResult)
		if (completeProperty) {
			if (result.isComplete) {
				outProps.put(completeProperty, "true")
			} else {
				outProps.put(completeProperty, "false")
			}
		}
		
//		// TODO - this is test code to be deleted
//		result = resultsApi.getAppBuilds()
//		outProps.put("AppBuilds", result.xmlString)
		
	}

	@Override
	protected void displayParameters() {
		Logger.info "   build_id='${build_id}'"
		Logger.info "   completeProperty='${completeProperty}'"
		super.displayParameters();
	}
	
	
}
