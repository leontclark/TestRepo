package plugin

import veracode.BusinessCriticality;
import veracode.DryRunHelper;
import veracode.VeracodeResultsApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class DidTheScanPass extends CoreVeraCodePlugin {
	// Arguments
	private String build_id
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new DidTheScanPass()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		build_id = inProps.build_id
		
		// Summarize parameters
		Logger.info "Calling DidTheScanPass"
		displayParameters()
		
		VeracodeResultsApi resultsApi = new VeracodeResultsApi(new ResultsAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// execute
		DryRunHelper.instance.dryRunXmlResults = super.dryRun
		def result = resultsApi.didTheScanPass(build_id)
		setOutputProperty(result.xmlResult)
		if (! result.passed) {
			throw new Exception( "The scan did not pass" )
		}
		
	}

	@Override
	protected void displayParameters() {
		Logger.info "   build_id='${build_id}'"
		super.displayParameters();
	}
	
	
}
