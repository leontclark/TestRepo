package plugin

import veracode.BusinessCriticality;
import veracode.VeracodeUploadApi;
import veracode.XmlResult;

import com.veracode.apiwrapper.wrappers.*
import com.ibm.issr.core.log.Logger

class FindSandbox extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String sandboxName
	private String createSandbox
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new FindSandbox()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		sandboxName = inProps.sandboxName
		createSandbox = inProps.createSandbox
		
		// Summarize parameters
		Logger.info "Find Sandbox"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		String sandbox_id = ""

		// Search for existing sandbox
		
		// Get the list of sandboxes (to look for named sandbox)
		XmlResult xmlResult = uploadApi.getSandboxList(appId)
		Logger.debug "Searching for named sandbox"
		xmlResult.xmlDom.sandbox.each { def sandbox ->
			Logger.debug "Found sandbox named '${sandbox.@sandbox_name}'"
			if (sandbox.@sandbox_name==sandboxName) {
				Logger.debug "Found existing sandbox with desired name!!"
				sandbox_id = sandbox.@sandbox_id
			}
		}
		
		if ((! sandbox_id) && createSandbox.toBoolean()) {
			// Create a new sandbox
			Logger.debug "Creating a new sandbox"
			sandbox_id = uploadApi.createSandbox(appId, sandboxName)
		}
				
		outProps.put("buildlife/sandbox_id", sandbox_id)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   sandboxName='${sandboxName}'"
		Logger.info "   createSandbox='${createSandbox}'"
		super.displayParameters();
	}
	
	
}
