package plugin

import veracode.VeracodeError;
import veracode.VeracodeHelper;
import veracode.XmlResult;
import groovy.lang.Closure;
import com.ibm.issr.core.log.Logger

/**
 * Implements core/common veracode plugin behavior, such as authentication information.
 * @author ltclark
 *
 */
class CoreVeraCodePlugin extends UCPluginStepImplementation {
	
	// Veracode authentication information
	protected String username = ""
	protected String password = ""
	protected String outputProperty = ""
	protected String dryRun = ""
	protected String dryRunFilename = ""
	protected String proxyHost = ""
	protected String proxyPort = ""
	
	// Helper class
	protected VeracodeHelper veracodeHelper = new VeracodeHelper();

	@Override
	public void performStep(String[] args, Closure theStep) {
		// Call the parent perform step while inserting additional closure steps
		super.performStep(args) {
			preExecute()
			theStep()
		}
	}
	
	/**
	 * This is code that is called just before the normal execution closure.
	 */
	void preExecute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		if (inProps.username) {
			username = inProps.username
		}
		if (inProps.password) {
			password = inProps.password
		}
		if (inProps.outputProperty) {
			outputProperty = inProps.outputProperty
		}
		if (inProps.dryRun) {
			dryRun = inProps.dryRun
		}
		if (inProps.dryRunFilename) {
			dryRunFilename = inProps.dryRunFilename
		}
		if (inProps.proxyHost) {
			proxyHost = inProps.proxyHost
		}
		if (inProps.proxyPort) {
			proxyPort = inProps.proxyPort
		}

	}

	@Override
	protected void displayParameters() {
		if (username) {
			Logger.info "   username='${username}'"
		} else {
			Logger.info "   username is not defined"
		}
		if (password) {
			Logger.info "   password='*********'"
		} else {
			Logger.info "   password is not defined"
		}
		if (outputProperty) {
			Logger.info "   outputProperty=${outputProperty}"
		} else {
			Logger.info "   outputProperty is not defined"
		}
		if (proxyHost) {
			Logger.info "   proxyHost=${proxyHost}"
		} else {
			Logger.info "   proxyHost is not defined"
		}
		if (proxyPort) {
			Logger.info "   proxyPort=${proxyPort}"
		} else {
			Logger.info "   proxyPort is not defined"
		}
		if (dryRun) {
			Logger.info "   dryRun= '${dryRun}'"
		}
		if (dryRunFilename) {
			Logger.info "   dryRunFilename= '${dryRunFilename}'"
		}
		super.displayParameters();
	}
	
	/**
	 * IF there is a defined 'outputProperty', then this sets the output property to the 
	 * string value of the xmlResult.
	 */
	protected void setOutputProperty( XmlResult xmlResult ) {
		String[] results = xmlResult.getXmlContents()
		String resultString = ""
		results.each {
			resultString = it + "\n\n" + resultString
		} 
		if (! resultString) {
			resultString = "--- NO RESULTS ARE AVAILABLE ---"
		}
		outProps.put(outputProperty, resultString)
	}

}
