package plugin

import java.text.SimpleDateFormat

import veracode.VeracodeUploadApi
import veracode.XmlResult

import com.ibm.issr.core.log.Logger
import com.veracode.apiwrapper.wrappers.*

class UploadFile extends CoreVeraCodePlugin {
	// Arguments
	private String appName
	private String filename
	private String sandbox_id
	private String save_as
	private String start_new_build
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new UploadFile()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************
		appName = inProps.appName
		filename = inProps.filename
		sandbox_id = inProps.sandbox_id
		save_as = inProps.save_as
		start_new_build = inProps.start_new_build
		
		// Summarize parameters
		Logger.info "Calling UploadFile"
		displayParameters()
		
		// execute
		VeracodeUploadApi uploadApi = new VeracodeUploadApi(new UploadAPIWrapper(), username, password, proxyHost, proxyPort )
		
		// get the app id
		String appId = uploadApi.getAppId(appName)
		if (! appId) {
			throw new Exception( "Unable to find an application named '${appName}'" )
		}
		
		// Optionally start a new Veracode build
		if (start_new_build.toBoolean()) {
			String version = (new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")).format(new Date())
			uploadApi.createBuild(appId, version)
		}

		// Upload the file
		XmlResult xmlResult = uploadApi.uploadFile(appId, filename, sandbox_id, save_as)
		setOutputProperty(xmlResult)
	}

	@Override
	protected void displayParameters() {
		Logger.info "   appName='${appName}'"
		Logger.info "   filename='${filename}'"
		Logger.info "   sandbox_id='${sandbox_id}'"
		Logger.info "   save_as='${save_as}'"
		Logger.info "   start_new_build='${start_new_build}'"
		super.displayParameters();
	}
	
	
}
