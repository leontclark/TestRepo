package com.ibm.issr.rest.client.permissions

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.rest.client.DeployClient

/**
 * The role based permissions are actually stored in a tree structure, but ultimately
 * are indexed by UIDs.  This class loads the tree and has UID lookup functions.
 * @author ltclark
 *
 */
class PermissionList extends LogTracingClass {
	private DeployClient theDeployClient = null;
	private permissionMap = [:]			// key = id, value = PermissionListNode
	
	/**
	 * Constructor
	 * @param deployClient Handle to the DeployClient for the server.
	 */
	public PermissionList( DeployClient deployClient ) {
		theDeployClient = deployClient;
		
		// Load the tree
		
		// First get and process the root nodes
		RestGet restGet =  new RestGet(theDeployClient.getRestClient())
		RestResponse response  = null
		def rootNodeList = null
		try {
			response = restGet.setPath("/security/resourceType")
					.get()
			response.throwExceptionOnBadResponse()
			rootNodeList = response.responseAsObject
		}
		finally {
			if (response != null) {
				response.close()
				response = null
			}
		}
		
		rootNodeList.each() { rootNode ->
			def actionList = null
			response = null
			try {
				response = restGet.setPath("/security/resourceType/${rootNode.name}/actions").get()
				response.throwExceptionOnBadResponse()
				actionList = response.responseAsObject
			}
			finally {
				if (response != null) {
					response.close()
					response = null
				}
			}
			
			actionList.each() { actionNode ->
				PermissionListNode permissionListNode = new PermissionListNode()
				permissionListNode.id = actionNode.id
				permissionListNode.name = actionNode.name
				permissionListNode.parentName = rootNode.name
				permissionMap.putAt( actionNode.id, permissionListNode)
			}
			
		}
	}
	
	
	/**
	 * Retrieves a permission list node by the id.
	 * @param id The ID of the leaf node
	 * @return The node or null if not found.
	 */
	public PermissionListNode getNodeById( String id ) {
		if (permissionMap.containsKey(id)) {
			return permissionMap[id]
		} else {
			return null
		}
	}
	
}

