package com.ibm.issr.rest.client.permissions

/**
 * One node in the permission list
 * @author ltclark
 *
 */
class PermissionListNode {
	// properties
	String id
	String name
	String description = ""
	String parentName		// Name of the parent element in the tree
}
