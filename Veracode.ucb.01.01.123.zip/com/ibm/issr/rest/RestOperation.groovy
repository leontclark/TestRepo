package com.ibm.issr.rest

import org.apache.http.HttpResponse

import com.ibm.issr.core.log.LogTracingClass

/**
 * This is the base class for the various REST operations, such as RestPut and RestGet.
 * This is not usable in and of itself.
 * 
 * @author ltclark
 *
 */
class RestOperation extends LogTracingClass {
	protected RestClient restClient;
	private String path;		// the path of the rest call
	HttpResponse response = null;
	// parameters
	private def parameters = []			// this is a list.  Each entry is a map with 'key' of key and 'value' of value.

	/**
	 * Adds a set of parameters by providing one map.
	 * @param paramMap This is a map of parameter values as a groovy map, such as [a:"vala",b:"valb"].
	 * @return Return 'this'
	 */
	public RestOperation addParameters( def paramMap ) {
		for (mapEntry in paramMap) {
			parameters.add( [key:mapEntry.key, value:mapEntry.value]);
		}
		return this;
	}
	
	/**
	 * Adds one parameter key/value pair.  Note
	 * @param key The key.
	 * @param value The string value.
	 * @return Returns 'this'
	 */
	public RestOperation addParameter( String key, String value ) {
		parameters.add( [key:key,value:value] )
		return this
	}

	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 */
	public RestOperation( RestClient restClient ) {
		this.restClient = restClient;
	}
	
	/**
	 * Sets the path of the rest call, such as "/rest/sample/call".  Doe NOT
	 * pass server information.
	 * @param path The path of the call.  Do NOT include parameters.
	 * @return Return 'this'.
	 */
	public RestOperation setPath( String path ) {
		this.path = path;
		return this;
	}

	/**
	 * Calculates and returns the full URL, which includes the server, path and parameters
	 * @return The full URL
	 */
	public String getFullUrl() {
		return restClient.buildFullUrl( path, parameters )
	}

	/**
	 * For debugging purposes, the standard 'toString' method has been expanded to include
	 * the full url for the Rest Operation.
	 */
	public String toString() {
		return super.toString() + "[URL = '${getFullUrl()}']"
	}
}
