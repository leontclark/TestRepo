package com.ibm.issr.ucd.entity

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.rest.RestClient;

/**
 * UCD Data Element which has a unique ID.  Note that
 * instances of this type are uniquely identified by their 'id' field.  So,
 * if two different instances of this have the same id, then they are
 * still considered to be equal (and have the same hashcode).
 * @author ltclark
 *
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=false, includes="id")
@groovy.transform.EqualsAndHashCode( includes="id", callSuper=false )
class UCDElementWithId extends LogTracingClass {
	String id;			// element's internal id
	protected RestClient restClient;
	
	// make id read only
	protected void setId(String value) { this.id = value }
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param elementId The id of the element
	 */
	public UCDElementWithId( RestClient restClient, String elementId ) {
		assert restClient
		assert elementId
		this.restClient = restClient
		this.id = elementId
	}

}
