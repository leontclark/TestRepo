package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse
import com.ibm.issr.ucd.manage.UCDArtifactTypeMgr

/**
 * Handle to a UCD Application with data functions in it.
 * 
 * @author ltclark
 *
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=true)
class UCDApplication extends UCDArtifact {
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param appName The name of the application
	 * @param appId The id of the application
	 */
	public UCDApplication( RestClient restClient, String appName, String appId ) {
		super( restClient, appName, appId, UCDArtifactTypeMgr.getInstance(restClient).getArtifactType("Application") )
	}
	
	
	/**
	 * Returns the list of member components of the Application as a list of type UCDComponent
	 */
	public getComponents() {
		def componentList = []
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/cli/application/componentsInApplication")
				.addParameter("application",this.name)
				.get()
			response.throwExceptionOnBadResponse()
			def responseList = response.getResponseAsObject()
	
			responseList.each { responseEntry ->
				componentList.add( new UCDComponent(restClient, responseEntry.name, responseEntry.id) )
			}
	
			return componentList	
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}	
	}
	
	
	/**
	 * Returns the list of member environments as a list of type UCDEnvironment
	 */
	public getEnvironments() {
		def environmentList = []
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/cli/application/environmentsInApplication")
				.addParameter("application",this.name)
				.get()
			response.throwExceptionOnBadResponse()
			def responseList = response.getResponseAsObject()
	
			responseList.each { responseEntry ->
				environmentList.add( new UCDEnvironment(restClient, responseEntry.name, responseEntry.id) )
			}
	
			return environmentList
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}

	}
	
	/**
	 * Returns a List of the Team Associations (UCDArtifactTeamAssociation).  Each UCDArtifact class must implement
	 * its own (unique) version of this function.
	 */
	public Set getTeamAssociations() {
		
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/rest/deploy/application/${this.id}")
			.get()
			response.throwExceptionOnBadResponse()
			
			return super.convertExtendedSecurityToTeamAssociations(response.getResponseAsObject())
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
}
