package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient
import com.ibm.issr.ucd.relationship.UCDArtifactTeamAssociation

/**
 * generic base class for a handle to one artifact in UCD, such as an Application or Component.
 * Each artifact has an associated type
 * @author ltclark
 *
 */
@groovy.transform.ToString(includeNames = true, includeFields=true, includeSuper=true, includes="artifactType")
abstract class UCDArtifact extends UCDElementWithNameAndId {
	// The type of the artifact (as a read-only field)
	UCDArtifactType artifactType
	
	// make sure artifactType is read only
	protected void setArtifactType(UCDArtifactType artifactType) { this.artifactType = artifactType }
	
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param artifactName The name of the artifact
	 * @param artifactId The id of the artifact
	 */
	public UCDArtifact( RestClient restClient, String artifactName, String artifactId, UCDArtifactType artifactType ) {
		super( restClient, artifactName, artifactId )
		this.artifactType = artifactType
	}
	
	/**
	 * Returns a Set of the Team Associations (UCDArtifactTeamAssociation).  Each UCDArtifact class must implement
	 * its own (unique) version of this function.  Implementations of this function will generally call
	 * convertExtendedSecurityToTeamAssociations() for a common implementation.
	 * @return List of type UCDArtifactTeamAssociation.  The list may be empty.
	 */
	abstract public Set getTeamAssociations()
	
	/**
	 * Most (if not all) Artifact Types which can be linked to Teams and Resource Roles store the
	 * information in a nested data element named 'extendedSecurity'.  This function converts that
	 * data into a Set of UCDArtifactTeamAssociation's.
	 * @param artifactData This is an artifact data structure definition retrieved from REST and
	 * already converted from JSON into a data structure.
	 * @return List of type UCDArtifactTeamAssociation.  The list may be empty.
	 */
	protected Set convertExtendedSecurityToTeamAssociations( artifactData ) {
		Set teamAssociationList = new HashSet()
		
		if (artifactData.extendedSecurity && artifactData.extendedSecurity.teams) {
			artifactData.extendedSecurity.teams.each() { assoc ->
				UCDTeam team = new UCDTeam( restClient, assoc.teamLabel, assoc.teamId )
				UCDResourceRole resourceRole
				if (assoc.resourceRoleId) {
					resourceRole = new UCDResourceRole(restClient, assoc.resourceRoleLabel, assoc.resourceRoleId )
				} else {
					resourceRole = null
				}
				UCDArtifactTeamAssociation newAssociation = new UCDArtifactTeamAssociation(this, team, resourceRole)
				teamAssociationList.add( newAssociation )
			}
		}

		return teamAssociationList

	}

}
