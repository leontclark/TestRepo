package com.ibm.issr.ucd.entity

import com.ibm.issr.rest.RestClient;

/**
 * Handle to the atomic definition of Permission 'Action' within UCD, such as "View Environments".  The API
 * for UCD uses the terminology of 'Action' to represent the specific permissions. A PermissionAction
 * has an id, name and description.  This class (by itself) does NOT tie the Permission Action to Roles,
 * Artifact/Resource Roles or teams.  This represents one permission defined in UCD.
 * @author ltclark
 *
 */
class UCDPermissionAction extends UCDElementWithNameAndId {
	private String description
	
	/**
	 * Constructor - ALL of the fields are required.
	 * @param restClient The handle to the REST API client.
	 * @param roleName The name of the role
	 * @param roleId The id of the role
	 */
	public UCDPermissionAction( RestClient restClient, String name, String id, String description ) {
		super( restClient, name, id )
		this.description = description
	}
	
	public String getDescription() {
		return description
	}

}
