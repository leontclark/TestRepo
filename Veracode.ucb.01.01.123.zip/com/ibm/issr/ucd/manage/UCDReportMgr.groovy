package com.ibm.issr.ucd.manage

import java.util.Set;

import com.ibm.issr.core.plugin.PluginHelper;
import com.ibm.issr.rest.RestClient;
import com.ibm.issr.rest.RestGet;
import com.ibm.issr.rest.RestResponse;


/**
 * Interface to the UCD 'report' api (/rest/report/...).
 * @author ltclark
 *
 */
class UCDReportMgr {
	/**
	 * Retrieves the list of historical application deployments which match the filter
	 * criteria.
	 * @param restClient The handle to the UCD server
	 * @param sortType The name of the sort field: application, environment, date, user, status, duration
	 * @param orderField The sort order.  One of: asc, desc
	 * @param dateRangeOption The date range.  One of: Current Week, Current Month, Current Quarter, Current Year, Prior Week, Prior Month, Prior Quarter, Prior Year, Custom.
	 * If 'custom', then the dateRangeStart and dateRangeEnd must be provided.
	 * @return Returns an ordered List of applicationProcessRequest IDs
	 */
	static List getApplicationProcessRequests( RestClient restClient, String sortType, String orderField, String dateRangeOption, String dateRangeStart, String dateRangeEnd ) {
		RestGet restGet = new RestGet(restClient)
		// RestResponse response = restGet.setPath("/rest/report/system/Deployment Detail/results")
		restGet.setPath("/rest/report/adHoc")
			.addParameter("type", "com.urbancode.ds.subsys.report.domain.deployment_report.DeploymentReport")

		// Validate and set sort order		
		def validOrderFields = [ "application", "environment", "date", "user", "status", "duration" ]
		def validSortTypes = ['asc', 'desc']
		if (! validOrderFields.contains(orderField.toLowerCase())) {
			PluginHelper.abortPlugin( "Invalid value of '${orderField}' for orderField")
		}
		if (! validSortTypes.contains(sortType.toLowerCase())) {
			PluginHelper.abortPlugin( "Invalid value of '${sortType}' for sortType")
		}
		restGet.addParameter("orderField", orderField.toLowerCase())
		restGet.addParameter("sortType", sortType.toLowerCase())
		
		// Validate and set date range
		def dateRangeOptionMap = [ 'current week':'currentWeek', 'current month':'currentMonth', 
			'current quarter':'currentQuarter', 'current year':'currentYear', 
			'prior week':'priorWeek', 'prior month':'priorMonth', 
			'prior quarter':'priorQuarter', 'prior year':'priorYear' ]
		String dateRangeClause = ""
		if (dateRangeOption.equalsIgnoreCase("custom")) {
			// todo
		} else if (dateRangeOptionMap.containsKey(dateRangeOption.toLowerCase())) {
			restGet.addParameter("dateRange", dateRangeOptionMap[dateRangeOption.toLowerCase()] )
		} else {
			PluginHelper.abortPlugin( "Invalid value of '${dateRangeOption}' for dateRangeOption")
		}

		RestResponse response = restGet.get()
		response.throwExceptionOnBadResponse()
		
		def responseObject = response.responseAsObject
		
		List retvalList = new ArrayList()
		responseObject.items[0].each() { deployEntry ->
			retvalList.add( deployEntry.applicationRequestId )
		}	
		
		return retvalList	
	}
}
