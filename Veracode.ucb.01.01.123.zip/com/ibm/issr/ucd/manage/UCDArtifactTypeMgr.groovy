package com.ibm.issr.ucd.manage

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.rest.RestClient;
import com.ibm.issr.rest.RestGet;
import com.ibm.issr.rest.RestResponse;
import com.ibm.issr.ucd.entity.UCDArtifactType;

/**
 * Singleton class used to manage and access the (stable) list of UCDArtifactTypeMgr
 * @author ltclark
 *
 */
class UCDArtifactTypeMgr extends LogTracingClass {
	/**
	 * Map of the artifact types.  The key is the String name.
	 * The value is the UCDArtifactType
	 */
	private def artifactTypeMap = [:]
	
	private static UCDArtifactTypeMgr instance = null;
	
	// private constructor as singleton
	private UCDArtifactTypeMgr( RestClient restClient ) {
		// load the list of artifact types
		RestGet restGet = new RestGet(restClient)
		RestResponse response = null
		try {
			response = restGet.setPath("/security/resourceType")
				.get()
			response.throwExceptionOnBadResponse()
			def responseObject = response.getResponseAsObject()
			
			// transfer the responseObject to the list of artifact types
			responseObject.each { responseEntry ->
				String artifactTypeName = responseEntry.name
				String artifactTypeId = responseEntry.id
				if (! (artifactTypeName.equalsIgnoreCase("Server Configuration") || artifactTypeName.equalsIgnoreCase("WEB UI"))) {
					artifactTypeMap.put( artifactTypeName, new UCDArtifactType(restClient, artifactTypeName, artifactTypeId) )
				}
			}
		}
		finally {
			if (response!=null) {
				response.close()
				response = null
			}
		}
	}
	
	/**
	 * Access the single instance of this class, creating it if needed.
	 * @param restClient The handle to the rest client.
	 * @return The handle to the one instance of this class.
	 */
	public static UCDArtifactTypeMgr getInstance( RestClient restClient ) {
		if (! instance) {
			instance = new UCDArtifactTypeMgr(restClient);
		}
		return instance;
	}
	
	
	/**
	 * Returns a 'List' of the Artifact Types of type UCDArtifactType
	 */
	public getArtifactTypes() {
		return artifactTypeMap.values().toList()
	}
	
	
	/**
	 * Returns the UCDArtifactType for the type name.  The name is mixed case with spaces, such as "Component" or
	 * "Component Template".  Throws exception if the artifact type is not found.
	 * @param artifactTypeName The name of the artifact type.
	 */
	public UCDArtifactType getArtifactType( String artifactTypeName ) {
		if (artifactTypeMap.containsKey(artifactTypeName)) {
			return artifactTypeMap[artifactTypeName]
		} else {
			throw new RuntimeException("Unable to find an artifact type named '${artifactTypeName}'")
		}
	}
}
