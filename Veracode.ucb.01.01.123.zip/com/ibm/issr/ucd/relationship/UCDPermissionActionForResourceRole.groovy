package com.ibm.issr.ucd.relationship

import com.ibm.issr.core.log.LogTracingClass;
import com.ibm.issr.ucd.entity.UCDPermissionAction;
import com.ibm.issr.ucd.entity.UCDResourceRole;
import com.ibm.issr.ucd.entity.UCDRole;

/**
 * Represents a PermissionAction associated with one specific UCDRole.  Note that
 * the role may be a Standard or Custom role.
 * @author ltclark
 *
 */
@groovy.transform.EqualsAndHashCode
class UCDPermissionActionForResourceRole extends LogTracingClass {
	UCDPermissionAction permissionAction
	/**
	 * The Resource Role, such as "DEV".  This may be null which means that it is either a Standard
	 * resource role OR that the permission is not related to Resources (Artifacts) such as a UI Permission.
	 */
	UCDResourceRole resourceRole
	
	// make the permissionAction and role read only
	protected void setPermissionAction( UCDPermissionAction permissionAction ) { this.permissionAction = permissionAction }
	protected void setRole( UCDRole role ) { this.role = role }
	
	/**
	 * Constructor.
	 * @param permissionAction The action, which is required (not null).
	 * @param resourceRole The role, which may be null.  null means either it is a permission for a 'Standard' ResourceRole
	 * or that it is a permission that is not related to Artifacts/Resources, such as a UI permission.
	 */
	public UCDPermissionActionForResourceRole( UCDPermissionAction permissionAction, UCDResourceRole resourceRole ) {
		assert permissionAction
		// resourceRole may be null
		this.permissionAction = permissionAction
		this.resourceRole = resourceRole
	}
}
